"""
ML Agent: TCGA Tumor Classification with LLM Integration.

A complete example of the tool use pattern combining ML and LLMs.
"""

__version__ = "1.0.0"
