# Splice Site Positions on Genomic Region
# Visualize splice sites as vertical bars

import matplotlib.pyplot as plt
import pandas as pd

# Filter the dataset for the specified genomic region
df_filtered = df[(df['position'] >= 7571719) & (df['position'] <= 7590868)]

# Map site types to colors
color_map = {'donor': 'blue', 'acceptor': 'red'}
df_filtered['color'] = df_filtered['site_type'].map(color_map)

# Create a figure and axis
plt.figure(figsize=(12, 6))

# Plot vertical lines for each splice site
plt.vlines(df_filtered['position'], ymin=-1, ymax=1, color=df_filtered['color'], linewidth=1)

# Add markers at the top of each bar
plt.scatter(df_filtered['position'], [1 if strand == '+' else -1 for strand in df_filtered['strand']], 
            color=df_filtered['color'], s=20, zorder=5)

# Annotate gene symbols
for i, row in df_filtered.iterrows():
    plt.text(row['position'], 1.05 if row['strand'] == '+' else -1.05, row['gene_symbol'], 
             horizontalalignment='center', fontsize=8)

# Set title and labels
plt.title("Splice Sites on chr17:7571719-7590868")
plt.xlabel("Genomic Position (base pairs)")
plt.yticks([-1, 1], ['-', '+'])
plt.grid(True)

# Add legend
handles = [plt.Line2D([0], [0], color='blue', lw=2, label='Donor'),
           plt.Line2D([0], [0], color='red', lw=2, label='Acceptor')]
plt.legend(handles=handles)

plt.tight_layout()