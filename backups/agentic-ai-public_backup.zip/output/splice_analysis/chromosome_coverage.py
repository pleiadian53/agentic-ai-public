# Splice Site Coverage Across Chromosomes
# Overview of splice site distribution by chromosome

import matplotlib.pyplot as plt
import numpy as np

# Data is already loaded as 'df'

# Prepare data
chromosome_labels = df['chrom']
splice_site_counts = df['splice_site_count']
gene_counts = df['gene_count']
transcript_counts = df['transcript_count']

# Create a colormap based on transcript counts
norm = plt.Normalize(transcript_counts.min(), transcript_counts.max())
colors = plt.cm.viridis(norm(transcript_counts))

# Create subplots
fig, axs = plt.subplots(2, 1, figsize=(14, 8), sharex=True)

# Top panel: Bar chart of splice site counts per chromosome
axs[0].bar(chromosome_labels, splice_site_counts, color=colors)
axs[0].set_title("Splice Site Distribution Across Chromosomes")
axs[0].set_ylabel("Splice Site Count")
axs[0].tick_params(axis='x', rotation=45)

# Bottom panel: Bar chart of gene counts per chromosome
axs[1].bar(chromosome_labels, gene_counts, color='lightblue')
axs[1].set_ylabel("Gene Count")
axs[1].tick_params(axis='x', rotation=45)

plt.tight_layout()