# Splice Site Patterns in Top Genes
# Heatmap of splice site types across genes with most splice sites

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Data is already loaded as 'df'

# Prepare the data by pivoting
heatmap_data = df.pivot("gene_symbol", "site_type", "count")

# Create the heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(heatmap_data, annot=True, fmt='d', cmap='YlOrRd', cbar_kws={'label': 'Count of Splice Sites'})
plt.title("Splice Site Type Distribution in Top Genes")
plt.xlabel("Site Type")
plt.ylabel("Gene Symbol")
plt.tight_layout()