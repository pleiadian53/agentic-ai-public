# Transcript Complexity by Exon Count
# Analyze transcript complexity using exon rank distribution

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

# Data is already loaded as 'df'
# Prepare data
df_filtered = df.groupby('transcript_id').agg(
    exon_count=('exon_count', 'max'),
    splice_site_count=('splice_site_count', 'sum')
).reset_index()

df_filtered = df_filtered[df_filtered['exon_count'] >= 10]

# Scatter plot
plt.figure(figsize=(12, 8))
scatter = plt.scatter(
    df_filtered['exon_count'],
    df_filtered['splice_site_count'],
    c=df_filtered['exon_count'],
    cmap='viridis',
    alpha=0.6,
    edgecolors='w'
)

# Trend line
X = df_filtered['exon_count'].values.reshape(-1, 1)
y = df_filtered['splice_site_count'].values
model = LinearRegression().fit(X, y)
predictions = model.predict(X)
plt.plot(df_filtered['exon_count'], predictions, color='red', linewidth=2)

# Annotate outliers
outlier_threshold = 2 * (df_filtered['exon_count'] - 1)
outliers = df_filtered[df_filtered['splice_site_count'] > outlier_threshold]
for i, row in outliers.iterrows():
    plt.annotate(row['gene_name'], (row['exon_count'], row['splice_site_count']), fontsize=9, alpha=0.7)

# Labels and title
plt.title("Transcript Complexity: Exon Count vs Splice Site Count")
plt.xlabel("Exon Count (max exon_rank)")
plt.ylabel("Splice Site Count per Transcript")
plt.colorbar(scatter, label='Exon Count')
plt.tight_layout()