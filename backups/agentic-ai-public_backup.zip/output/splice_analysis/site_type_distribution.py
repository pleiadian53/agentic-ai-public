# Splice Site Type Distribution by Chromosome
# Analyze splice site types across chromosomes

import matplotlib.pyplot as plt
import pandas as pd

# Data is already loaded as 'df'

# Check for empty data
if df.empty:
    raise ValueError("The DataFrame is empty.")

# Group by chromosome and site type, then sum counts
grouped_data = df.groupby(['chrom', 'site_type']).sum().reset_index()

# Pivot the data for stacked bar chart
pivot_data = grouped_data.pivot(index='chrom', columns='site_type', values='count').fillna(0)

# Plotting
plt.figure(figsize=(12, 6))
pivot_data.plot(kind='bar', stacked=True, color=['blue', 'orange'], ax=plt.gca())

plt.title("Splice Site Type Distribution by Chromosome")
plt.xlabel("Chromosome")
plt.ylabel("Count of Splice Sites")
plt.xticks(rotation=45)
plt.legend(title='Site Type')
plt.tight_layout()