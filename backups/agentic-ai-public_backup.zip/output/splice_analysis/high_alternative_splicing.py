# Genes with Most Splice Sites
# Identify genes with many splice sites

import matplotlib.pyplot as plt
import numpy as np

# Data is already loaded as 'df'
top_genes = df.groupby('gene_name').filter(lambda x: x['splice_site_count'].sum() > 20)
top_genes = top_genes.groupby('gene_name')['splice_site_count'].sum().nlargest(20).reset_index()

# Sort by splice site count
top_genes = top_genes.sort_values(by='splice_site_count', ascending=True)

# Create a colormap based on max_exon_rank
norm = plt.Normalize(df['max_exon_rank'].min(), df['max_exon_rank'].max())
colors = plt.cm.viridis(norm(df.loc[df['gene_name'].isin(top_genes['gene_name']), 'max_exon_rank']))

plt.figure(figsize=(10, 6))
bars = plt.barh(top_genes['gene_name'], top_genes['splice_site_count'], color=colors)

# Add colorbar
sm = plt.cm.ScalarMappable(cmap='viridis', norm=norm)
sm.set_array([])
plt.colorbar(sm, label='Max Exon Rank')

plt.title("Genes with Most Splice Sites (Standard Chromosomes)")
plt.suptitle("Filtered to genes with > 20 splice sites", fontsize=10)
plt.xlabel("Number of Splice Sites")
plt.ylabel("Gene Name")
plt.tight_layout()