# Genes with Most Splice Sites
# Identify genes with many splice sites

import matplotlib.pyplot as plt
import numpy as np

# Data is already loaded as 'df'
top_genes = df.groupby('gene_name').agg(total_splice_sites=('splice_site_count', 'sum'), 
                                         max_exon_rank=('max_exon_rank', 'max')).reset_index()
top_genes = top_genes[top_genes['total_splice_sites'] > 20].nlargest(20, 'total_splice_sites')

plt.figure(figsize=(12, 8))
norm = plt.Normalize(top_genes['max_exon_rank'].min(), top_genes['max_exon_rank'].max())
colors = plt.cm.get_cmap('viridis')(norm(top_genes['max_exon_rank']))

bars = plt.barh(top_genes['gene_name'], top_genes['total_splice_sites'], color=colors)
plt.colorbar(plt.cm.ScalarMappable(norm=norm, cmap='viridis'), label='Max Exon Rank')
plt.title("Genes with Most Splice Sites (MANE Dataset)")
plt.suptitle("Filtered to genes with > 20 splice sites", fontsize=10)
plt.xlabel("Total Number of Splice Sites (Count)")
plt.ylabel("Gene Name")
plt.grid(axis='x', linestyle='--', alpha=0.7)
for bar in bars:
    plt.text(bar.get_width(), bar.get_y() + bar.get_height()/2, 
             f'{bar.get_width()}', va='center', ha='left', fontsize=10)
plt.tight_layout()