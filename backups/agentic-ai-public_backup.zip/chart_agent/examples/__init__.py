"""Domain-specific chart generation examples."""
