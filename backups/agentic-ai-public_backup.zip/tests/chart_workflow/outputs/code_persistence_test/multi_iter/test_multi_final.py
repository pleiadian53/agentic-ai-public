import pandas as pd
import matplotlib.pyplot as plt

# Grouping by coffee_name and summing the prices
grouped_data = df.groupby('coffee_name')['price'].sum().reset_index()

# Creating a bar chart
plt.figure(figsize=(12, 7))
plt.bar(grouped_data['coffee_name'], grouped_data['price'], color='cornflowerblue')
plt.title('Total Sales Price per Coffee Type')
plt.xlabel('Coffee Type')
plt.ylabel('Total Sales Price ($)')
plt.xticks(rotation=45, ha='right')
plt.grid(axis='y')

# Saving the chart
plt.savefig('tests/chart_workflow/outputs/code_persistence_test/multi_iter/test_multi_v4.png', dpi=300)
plt.close()