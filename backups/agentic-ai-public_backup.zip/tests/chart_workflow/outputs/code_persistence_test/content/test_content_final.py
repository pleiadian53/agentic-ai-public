import pandas as pd
import matplotlib.pyplot as plt

# Group data by coffee name and sum the prices
coffee_sales = df.groupby('coffee_name')['price'].sum().reset_index()

# Sort the dataframe by total sales
coffee_sales = coffee_sales.sort_values(by='price', ascending=False)

# Create a bar chart
plt.figure(figsize=(10, 6))
plt.bar(coffee_sales['coffee_name'], coffee_sales['price'], color='steelblue')
plt.title('Total Sales by Coffee Type')
plt.xlabel('Coffee Name')
plt.ylabel('Total Sales (in USD)')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()

# Save the chart
plt.savefig('tests/chart_workflow/outputs/code_persistence_test/content/test_content_v3.png', dpi=300)
plt.close()