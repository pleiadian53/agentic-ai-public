import pandas as pd
import matplotlib.pyplot as plt

# Grouping the data by coffee name and summing the prices
coffee_sales = df.groupby('coffee_name')['price'].sum().reset_index()

# Creating a bar chart
plt.figure(figsize=(10, 6))
plt.bar(coffee_sales['coffee_name'], coffee_sales['price'], color='skyblue')
plt.title('Total Price of Coffee Sales by Coffee Type')
plt.xlabel('Coffee Name')
plt.ylabel('Total Price')
plt.xticks(rotation=45)
plt.tight_layout()

# Saving the chart to the specified path
plt.savefig('tests/chart_workflow/outputs/code_persistence_test/execution/test_exec_v2.png', dpi=300)
plt.close()