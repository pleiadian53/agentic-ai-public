import pandas as pd
import matplotlib.pyplot as plt

# Grouping data by coffee type and summing the sales
coffee_sales = df.groupby('coffee_name')['price'].sum().reset_index()

# Creating the bar chart
plt.figure(figsize=(10, 6))
plt.bar(coffee_sales['coffee_name'], coffee_sales['price'], color='skyblue', edgecolor='black')
plt.title('Coffee Sales by Type')
plt.xlabel('Coffee Type')
plt.ylabel('Total Sales ($)')
plt.xticks(rotation=45, ha='right')
plt.grid(axis='y')

# Saving the chart
plt.savefig('tests/chart_workflow/outputs/code_persistence_test/default/test_persist_v2.png', dpi=300)
plt.close()