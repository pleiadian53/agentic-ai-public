import pandas as pd
import matplotlib.pyplot as plt

# Group by coffee_name and sum the prices
coffee_sales = df.groupby('coffee_name')['price'].sum().reset_index()

# Plotting
plt.figure(figsize=(10, 6))
plt.bar(coffee_sales['coffee_name'], coffee_sales['price'], color='cornflowerblue')
plt.title('Total Price of Coffees Sold')
plt.xlabel('Coffee Name')
plt.ylabel('Total Price ($)')
plt.xticks(rotation=45)
plt.grid(axis='y')

# Save the chart
plt.savefig('tests/chart_workflow/outputs/code_persistence_test/validity/test_valid_v2.png', dpi=300)
plt.close()