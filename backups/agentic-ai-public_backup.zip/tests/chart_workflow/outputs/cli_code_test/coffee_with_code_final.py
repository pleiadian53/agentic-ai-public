import pandas as pd
import matplotlib.pyplot as plt

# Grouping data by coffee name and summing the price
coffee_sales = df.groupby('coffee_name', as_index=False)['price'].sum()

# Creating the bar chart
plt.figure(figsize=(10, 6))
plt.bar(coffee_sales['coffee_name'], coffee_sales['price'], color='skyblue')
plt.title('Total Coffee Sales by Type')
plt.xlabel('Type of Coffee')
plt.ylabel('Total Sales in USD')
plt.xticks(rotation=30, ha='right')
plt.tight_layout()

# Saving the chart
plt.savefig('tests/chart_workflow/outputs/cli_code_test/coffee_with_code_v3.png', dpi=300)
plt.close()