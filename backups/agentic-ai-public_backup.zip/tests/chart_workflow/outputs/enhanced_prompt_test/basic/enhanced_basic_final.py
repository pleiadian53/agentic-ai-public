import pandas as pd
import matplotlib.pyplot as plt

# Group by coffee_name and sum the price to get total sales
sales_by_coffee = df.groupby('coffee_name')['price'].sum().sort_values(ascending=False)

# Create a horizontal bar chart
plt.figure(figsize=(10, 6))
plt.barh(sales_by_coffee.index, sales_by_coffee.values, color='skyblue')
plt.title('Total Sales by Coffee Type', fontsize=16)
plt.xlabel('Total Sales ($)', fontsize=12)
plt.ylabel('Coffee Type', fontsize=12)
plt.gca().invert_yaxis()
plt.grid(axis='x', linestyle='--', alpha=0.7)

# Save the chart
plt.tight_layout()
plt.savefig('/Users/pleiadian53/work/agentic-ai-public/tests/chart_workflow/outputs/enhanced_prompt_test/basic/enhanced_basic_v2.png', dpi=300)
plt.close()