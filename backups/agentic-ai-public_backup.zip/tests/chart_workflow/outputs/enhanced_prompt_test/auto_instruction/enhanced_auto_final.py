import pandas as pd
import matplotlib.pyplot as plt

# Assume the dataframe `df` is already available

# Prepare the multi-panel figure
fig, axs = plt.subplots(3, 1, figsize=(12, 15))
plt.style.use('ggplot')

# --- 1) Horizontal bar chart of time showing top categories and their counts ---
time_counts = df['time'].value_counts().head(10)  # Focus on top 10 for readability
time_counts.plot(kind='barh', ax=axs[0], color='deepskyblue')
axs[0].set_title('Top 10 Purchase Times')
axs[0].set_xlabel('Count')
axs[0].set_ylabel('Time')
axs[0].invert_yaxis()

# --- 2) Grouped bar chart comparing time against cash type (with simplified time categories) ---
df['hour'] = df['time'].apply(lambda x: x.split(':')[0])  # Simplify to hourly
cash_time_counts = df.groupby(['hour', 'cash_type']).size().unstack(fill_value=0)
cash_time_counts.plot(kind='bar', ax=axs[1], width=0.8, color=['gold', 'lightgreen'])
axs[1].set_title('Purchase Count by Hour and Cash Type')
axs[1].set_xlabel('Hour')
axs[1].set_ylabel('Count')
axs[1].legend(title='Cash Type')
axs[1].tick_params(axis='x', rotation=0)

# --- 3) Box plot for price distribution ---
axs[2].boxplot(df['price'], vert=False, patch_artist=True, boxprops=dict(facecolor='lightcoral', color='black'))
axs[2].set_title('Price Distribution with Notable Percentiles')
axs[2].set_xlabel('Price')
axs[2].annotate(f"Median: {df['price'].median():.2f}", xy=(df['price'].median(), 1), xytext=(df['price'].median(), 1.2),
                arrowprops=dict(facecolor='black', shrink=0.05), horizontalalignment='center')

plt.tight_layout()
plt.savefig('/Users/pleiadian53/work/agentic-ai-public/tests/chart_workflow/outputs/enhanced_prompt_test/auto_instruction/enhanced_auto_v2.png', dpi=300)
plt.close()