import pandas as pd
import matplotlib.pyplot as plt

# Sample data in DataFrame `df`
# Data is assumed to be loaded as per the previous context

# Group by coffee_name and sum prices for total sales
total_sales = df.groupby('coffee_name').agg(total_sales=('price', 'sum')).reset_index()

# Define a color palette that is colorblind-friendly
colors = ['#377eb8', '#e41a1c', '#4daf4a', '#984ea3', '#ff7f00', '#ffff33', '#a65628']

# Plotting using a horizontal bar chart
plt.figure(figsize=(10, 6))
plt.barh(total_sales['coffee_name'], total_sales['total_sales'], color=colors[:len(total_sales)])

plt.title('Total Coffee Sales by Type', fontsize=16)
plt.xlabel('Total Sales ($)', fontsize=14)
plt.ylabel('Coffee Type', fontsize=14)

# Simplified grid (only major x-axis lines)
plt.grid(axis='x', linestyle='--', linewidth=0.7, alpha=0.7)

# Save the chart
plt.savefig('/Users/pleiadian53/work/agentic-ai-public/tests/chart_workflow/outputs/enhanced_prompt_test/extended/enhanced_extended_v3.png', dpi=300)
plt.close()