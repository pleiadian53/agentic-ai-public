import pandas as pd
import matplotlib.pyplot as plt

# Group by coffee_name and sum the prices
sales_by_coffee = df.groupby('coffee_name')['price'].sum().sort_values(ascending=True)

# Create a horizontal bar chart
plt.figure(figsize=(10, 6))
sales_by_coffee.plot(kind='barh', color='teal')

# Add titles and labels
plt.title('Total Sales by Coffee Type', fontsize=16)
plt.xlabel('Total Sales ($)', fontsize=14)
plt.ylabel('Coffee Type', fontsize=14)

# Remove the gridlines for a cleaner look
plt.grid(axis='x', linestyle='--')

# Save the chart
plt.tight_layout()
plt.savefig('charts/test_run/coffee_sales_v2.png', dpi=300)

# Close the plot
plt.close()