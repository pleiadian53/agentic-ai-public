import pandas as pd
import matplotlib.pyplot as plt

# Assuming df is already defined and available
# Grouping sales by week and summing prices
df['week'] = df['date'].dt.to_period('W').apply(lambda r: r.start_time)
sales_trends = df.groupby('week')['price'].sum().reset_index()

# Plotting the trends
plt.figure(figsize=(12, 6))
plt.plot(sales_trends['week'], sales_trends['price'], marker='o', linestyle='-', color='b', label='Total Sales')

# Adding titles and labels
plt.title('Weekly Coffee Sales Trends', fontsize=16)
plt.xlabel('Week', fontsize=14)
plt.ylabel('Total Sales ($)', fontsize=14)
plt.xticks(rotation=45)
plt.legend(loc='upper left')
plt.grid(visible=True, which='both', linestyle='--', linewidth=0.5)

# Saving the chart
plt.tight_layout()
plt.savefig('charts/test_descriptions/sales_trends_v2.png', dpi=300)
plt.close()