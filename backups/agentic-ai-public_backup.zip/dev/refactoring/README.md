# Refactoring Documentation

This directory contains development notes and documentation related to refactoring efforts in the agentic-ai project.

## Purpose

These documents are for **internal development use only** and are not intended for public distribution. They track:
- Architectural changes
- Code reorganization
- Migration paths
- Breaking changes
- Implementation decisions

## Contents

- **`email_agent_refactoring_2025.md`** - Self-containment refactoring of email_agent package (Nov 2025)
- **`tool_use_package_refactoring.md`** - Original tool_use package creation from M3_UGL notebooks

## Git Ignore

The `dev/` directory should be added to `.gitignore` to prevent these internal notes from being pushed to the repository.

## Organization

For future refactoring documentation, follow this naming pattern:
```
dev/refactoring/<component>_<description>_<year>.md
```

Examples:
- `dev/refactoring/research_agent_refactoring_2025.md`
- `dev/refactoring/database_migration_2025.md`
- `dev/refactoring/api_v2_breaking_changes_2025.md`
