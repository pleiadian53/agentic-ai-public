# Development Directory

This directory contains development-specific documents, notes, and temporary files that should **not** be committed to version control.

## Purpose

- **Testing notes**: Results from development testing and experiments
- **Schema updates**: Migration notes and data transformation logs
- **Work-in-progress**: Draft documentation and planning documents
- **Debugging artifacts**: Temporary analysis and troubleshooting notes
- **Personal notes**: Developer-specific observations and reminders

## Structure

```
dev/
├── chart_agent/          # Chart agent development notes
│   ├── TESTING_SUMMARY.md
│   └── SCHEMA_UPDATE_SUMMARY.md
├── multiagent/           # Multi-agent system development notes
└── README.md             # This file
```

## Git Ignore

This entire directory is excluded from version control via `.gitignore`:

```gitignore
# Development temporary files
dev/
```

## Guidelines

1. **Keep it local**: Nothing in `dev/` should be pushed to the repository
2. **Organize by topic**: Use subdirectories matching the main project structure
3. **Document experiments**: Record testing results, schema changes, and decisions
4. **Clean up periodically**: Remove obsolete notes when work is complete
5. **Move to docs/**: If content becomes valuable for others, move it to official documentation

## What Belongs Here

✅ **Include:**
- Testing summaries and experiment results
- Schema migration notes and data transformation logs
- Draft documentation and planning documents
- Personal development notes and TODOs
- Debugging session notes
- Performance benchmarking results
- API exploration and testing scripts

❌ **Don't Include:**
- Sensitive credentials or API keys (use `.env` instead)
- Large binary files or datasets (use `data/` with `.gitignore`)
- Production-ready documentation (use `docs/` or `README.md`)
- Reusable code (belongs in the main codebase)

## Example Files

- `TESTING_SUMMARY.md` - Results from testing new features
- `SCHEMA_UPDATE_SUMMARY.md` - Notes on data schema changes
- `PERFORMANCE_NOTES.md` - Benchmarking and optimization notes
- `TODO.md` - Personal task lists and reminders
- `DECISIONS.md` - Design decisions and rationale

## Related Directories

- `docs/` - Official project documentation (committed to git)
- `output/` - Generated outputs and artifacts (gitignored)
- `data/` - Datasets and data files (gitignored)
- `tests/` - Test suite (committed to git)
