**Uvicorn** is an **ASGI (Asynchronous Server Gateway Interface) server** for Python.





Great question! Let me explain what happens when you run this command and how uvicorn works.

## What Happens: `uvicorn email_service:app --reload --timeout-keep-alive 1200`

### The Process Breakdown

```
uvicorn email_service:app --reload --timeout-keep-alive 1200
         │              │    │       │
         │              │    │       └─ Keep connections alive for 1200 seconds
         │              │    └─ Auto-reload on code changes
         │              └─ The FastAPI app instance to run
         └─ Module name (email_service.py)
```

### Step-by-Step Execution

1. **uvicorn starts up**
   - Looks for [email_service.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/email_agent/server/email_service.py:0:0-0:0) in the current directory
   - Imports the module: `import email_service`
   - Finds the `app` variable: `email_service.app`

2. **Loads the FastAPI application**
   ```python
   # From email_service.py
   from fastapi import FastAPI
   
   app = FastAPI(title="Email Simulation API")  # ← This is what uvicorn runs
   ```

3. **Starts the ASGI server**
   - Binds to `http://127.0.0.1:8000` (default)
   - Listens for HTTP requests
   - Routes requests to your FastAPI endpoints

4. **Watches for changes** (due to `--reload`)
   - Monitors [email_service.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/email_agent/server/email_service.py:0:0-0:0) and imported modules
   - Automatically restarts if code changes

### What is Uvicorn?

**Uvicorn** is an **ASGI (Asynchronous Server Gateway Interface) server** for Python.

#### Key Characteristics

- **Lightning-fast**: Built on `uvloop` and `httptools` for high performance
- **Async-native**: Designed for async Python frameworks (FastAPI, Starlette)
- **Production-ready**: Used in production by many companies
- **Simple**: Easy to use with minimal configuration

#### ASGI vs WSGI

```
Traditional (WSGI):          Modern (ASGI):
┌─────────────┐             ┌─────────────┐
│   Gunicorn  │             │   Uvicorn   │
│   (WSGI)    │             │   (ASGI)    │
└──────┬──────┘             └──────┬──────┘
       │                           │
       ▼                           ▼
┌─────────────┐             ┌─────────────┐
│   Flask     │             │   FastAPI   │
│   Django    │             │   Starlette │
└─────────────┘             └─────────────┘
Synchronous only            Async + Sync support
```

### Primary Use Cases

#### 1. **FastAPI Applications** (Most Common)
```python
# email_service.py
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello"}

# Run with: uvicorn email_service:app
```

#### 2. **Starlette Applications**
```python
from starlette.applications import Starlette
from starlette.responses import JSONResponse

app = Starlette()

@app.route('/')
async def homepage(request):
    return JSONResponse({'hello': 'world'})
```

#### 3. **Any ASGI Application**
```python
async def app(scope, receive, send):
    await send({
        'type': 'http.response.start',
        'status': 200,
        'headers': [[b'content-type', b'text/plain']],
    })
    await send({
        'type': 'http.response.body',
        'body': b'Hello, world!',
    })
```

### Does Uvicorn Invoke [email_service.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/email_agent/server/email_service.py:0:0-0:0)?

**Yes!** Here's exactly what happens:

#### 1. **Import Phase**
```python
# Uvicorn does this internally:
import email_service  # Imports the module

# This triggers all module-level code in email_service.py:
from fastapi import FastAPI
from email_database import SessionLocal, engine
from email_models import Base, Email

app = FastAPI(title="Email Simulation API")  # ← Created
# ... all your route definitions ...
```

#### 2. **App Discovery**
```python
# Uvicorn then accesses:
application = email_service.app  # Gets the FastAPI instance
```

#### 3. **Server Startup**
```python
# Uvicorn starts the ASGI server with your app:
# - Binds to host:port
# - Starts event loop
# - Begins accepting HTTP requests
```

### What Happens When a Request Comes In

```
1. Client Request
   │
   ▼
2. Uvicorn receives HTTP request
   │
   ▼
3. Uvicorn parses request into ASGI format
   │
   ▼
4. FastAPI router matches URL to endpoint
   │
   ▼
5. Your endpoint function executes
   │  (e.g., @app.get("/emails"))
   ▼
6. FastAPI serializes response
   │
   ▼
7. Uvicorn sends HTTP response to client
```

### Command-Line Options Explained

```bash
uvicorn email_service:app --reload --timeout-keep-alive 1200
```

| Option                      | Purpose                | Details                                      |
| --------------------------- | ---------------------- | -------------------------------------------- |
| `email_service:app`         | **App location**       | Module `email_service`, variable `app`       |
| `--reload`                  | **Auto-reload**        | Restart server when code changes (dev only!) |
| `--timeout-keep-alive 1200` | **Connection timeout** | Keep idle connections alive for 20 minutes   |

### Additional Useful Options

```bash
# Specify host and port
uvicorn email_service:app --host 0.0.0.0 --port 8000

# Production mode (no reload, multiple workers)
uvicorn email_service:app --workers 4

# With SSL
uvicorn email_service:app --ssl-keyfile key.pem --ssl-certfile cert.pem

# Custom log level
uvicorn email_service:app --log-level debug
```

### Why `--timeout-keep-alive 1200`?

This is set to **1200 seconds (20 minutes)** because:

1. **LLM requests can be slow**: Tool-calling workflows may take time
2. **Prevents premature disconnection**: Client stays connected during long operations
3. **Default is 5 seconds**: Too short for our use case

### Development vs Production

**Development (what you're using):**
```bash
uvicorn email_service:app --reload --timeout-keep-alive 1200
```
- ✅ Auto-reload on changes
- ✅ Detailed error messages
- ❌ Single process (not scalable)

**Production (recommended):**
```bash
uvicorn email_service:app --workers 4 --host 0.0.0.0 --port 8000
```
- ✅ Multiple worker processes
- ✅ Better performance
- ✅ Can handle more concurrent requests
- ❌ No auto-reload

### Summary

**What uvicorn does:**
1. ✅ Imports [email_service.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/email_agent/server/email_service.py:0:0-0:0) as a Python module
2. ✅ Finds the `app` variable (your FastAPI instance)
3. ✅ Starts an ASGI server on port 8000
4. ✅ Routes HTTP requests to your FastAPI endpoints
5. ✅ Watches for code changes and auto-reloads (with `--reload`)

**Primary use cases:**
- 🚀 Running FastAPI applications (most common)
- 🚀 Running Starlette applications
- 🚀 Any async Python web framework using ASGI
- 🚀 High-performance async web services

**Yes, it invokes [email_service.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/email_agent/server/email_service.py:0:0-0:0)** by importing it and running the `app` instance it finds there!



---

@CONFIGURATION.md#L60-70 

This notebook came from the course repo so I am not sure how practical it is just yet to send a "real email" 

So if I configured "user_email" to be my real email address: "andromedan53@gmail.com", will it be able to send emails there? how do we test it? 

---

Great question! The short answer is: **No, this is a simulated email system** - it won't send real emails to your Gmail address. Let me explain what's actually happening:

## What This Email System Actually Does

### It's a **Simulation/Mock System**

The email agent uses a **local SQLite database** to simulate an email inbox. It's designed for:
- ✅ Learning and demonstrating LLM tool use patterns
- ✅ Testing agent workflows without external dependencies
- ✅ Safe experimentation without sending real emails

### What `user_email` Actually Controls

The `user_email` configuration is used for:

1. **Agent context** - The LLM knows "your" email address for composing messages
2. **Filtering** - When searching for emails sent to/from you
3. **UI display** - Showing your email in the interface

```python
# In llm_service.py
prompt_ = f"""
- You are an AI assistant specialized in managing emails.
- If needed, my email address is "{USER_EMAIL}" so you can use it 
  to send emails or perform actions related to my account.
{prompt}
"""
```

## How the "Email Sending" Actually Works

Perfect! Now I can show you exactly what happens:

## What Actually Happens When You "Send an Email"

### The Flow

```
1. Agent calls: send_email("andromedan53@gmail.com", "Test", "Hello")
   ↓
2. HTTP POST to: http://localhost:8000/send
   ↓
3. email_service.py receives the request
   ↓
4. Creates a new row in SQLite database:
   {
     "sender": "you@mail.com",
     "recipient": "andromedan53@gmail.com",
     "subject": "Test",
     "body": "Hello",
     "timestamp": "2025-11-05T17:11:00",
     "read": false
   }
   ↓
5. Returns success ✅
   ↓
6. NO actual email is sent to Gmail! 📧❌
```

### The Database

```bash
# The "emails" are just SQLite records:
$ sqlite3 tool_use/email_agent/emails.db
sqlite> SELECT * FROM emails WHERE recipient='andromedan53@gmail.com';

id | sender        | recipient              | subject | body  | timestamp | read
1  | you@mail.com  | andromedan53@gmail.com | Test    | Hello | 2025-...  | 0
```

## Testing the Simulated System

### 1. Start the Server

```bash
cd tool_use/email_agent/server
uvicorn email_service:app --reload --timeout-keep-alive 1200
```

### 2. Test "Sending" an Email

```bash
# Send to your Gmail (simulated)
curl -X POST http://localhost:8000/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient": "andromedan53@gmail.com",
    "subject": "Test Email",
    "body": "This is a test"
  }'
```

**Response:**
```json
{
  "id": 7,
  "sender": "you@mail.com",
  "recipient": "andromedan53@gmail.com",
  "subject": "Test Email",
  "body": "This is a test",
  "timestamp": "2025-11-05T17:11:00.123456",
  "read": false
}
```

### 3. Verify It's in the Database

```bash
# List all emails
curl http://localhost:8000/emails

# Search for your email
curl "http://localhost:8000/emails/search?q=andromedan53"
```

### 4. Test with the Agent

```python
# In the notebook or via LLM service
prompt = "Send an email to andromedan53@gmail.com saying hello"

# The agent will:
# 1. Call send_email("andromedan53@gmail.com", "Hello", "...")
# 2. Create a database record
# 3. Return success
# 4. But NO real email is sent!
```

## If You Want to Send REAL Emails

To actually send emails, you would need to integrate a real email service. Here are the options:

### Option 1: SMTP (Gmail, Outlook, etc.)

```python
import smtplib
from email.mime.text import MIMEText

def send_real_email(recipient, subject, body):
    """Send actual email via SMTP"""
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = 'your-email@gmail.com'
    msg['To'] = recipient
    
    # Gmail SMTP
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login('your-email@gmail.com', 'your-app-password')
        smtp.send_message(msg)
```

**Requirements:**
- Gmail App Password (not your regular password)
- SMTP enabled
- Proper authentication

### Option 2: Email API Services

**SendGrid:**
```python
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

def send_via_sendgrid(recipient, subject, body):
    message = Mail(
        from_email='your-email@example.com',
        to_emails=recipient,
        subject=subject,
        html_content=body
    )
    sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
    response = sg.send(message)
```

**Other options:**
- Mailgun
- AWS SES
- Postmark
- Resend

### Option 3: Modify the Email Service

You could modify [email_service.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/email_agent/server/email_service.py:0:0-0:0) to actually send emails:

```python
@app.post("/send", response_model=EmailOut)
def send_email(email: EmailCreate, db: Session = Depends(get_db)):
    # Save to database (for records)
    new_email = Email(
        recipient=email.recipient,
        subject=email.subject,
        body=email.body,
        sender="you@mail.com",
    )
    db.add(new_email)
    db.commit()
    db.refresh(new_email)
    
    # NEW: Actually send the email
    try:
        send_real_email_via_smtp(
            recipient=email.recipient,
            subject=email.subject,
            body=email.body
        )
    except Exception as e:
        # Handle email sending errors
        print(f"Failed to send real email: {e}")
    
    return new_email
```

## Summary

**Current System (Simulated):**
- ✅ Safe for learning and testing
- ✅ No external dependencies
- ✅ Fast and reliable
- ✅ No risk of accidentally spamming
- ❌ Doesn't send real emails

**To Send Real Emails:**
- Need SMTP credentials or API keys
- Add email sending logic to [email_service.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/email_agent/server/email_service.py:0:0-0:0)
- Handle authentication, rate limits, errors
- Be careful with testing (don't spam!)

**Recommendation:**
Keep the simulated system for learning the tool use patterns. If you need real email functionality later, you can add it as an enhancement. The current system is perfect for understanding how LLM agents orchestrate tools without the complexity of real email infrastructure!

Would you like me to show you how to add real email sending capability, or are you happy with the simulation for now?