Great question! AISuite needs to know which LLM to use, and there are several ways to specify this:

## How AISuite Determines Which LLM to Call

### Method 1: Specify Model in Each API Call (Most Common)

```python
import aisuite as ai

client = ai.Client()

# Specify the model when making the call
response = client.chat.completions.create(
    model="openai:gpt-4o",  # ← This tells AISuite which LLM to use
    messages=[{"role": "user", "content": "Hello"}]
)
```

**Format**: `"provider:model-name"`

**Examples:**
```python
model="openai:gpt-4o"           # OpenAI's GPT-4o
model="openai:gpt-4o-mini"      # OpenAI's GPT-4o-mini
model="openai:gpt-3.5-turbo"    # OpenAI's GPT-3.5
model="anthropic:claude-3-5-sonnet-20241022"  # Anthropic's Claude
model="google:gemini-1.5-pro"   # Google's Gemini
model="azure:gpt-4"             # Azure OpenAI
```

### Method 2: Set Default Model in Client (Less Common)

Some implementations allow setting a default:

```python
import aisuite as ai

# Initialize with default model
client = ai.Client(default_model="openai:gpt-4o")

# Use default model
response = client.chat.completions.create(
    messages=[{"role": "user", "content": "Hello"}]
)

# Override default for specific call
response = client.chat.completions.create(
    model="anthropic:claude-3-5-sonnet-20241022",  # Override
    messages=[{"role": "user", "content": "Hello"}]
)
```

### Method 3: Environment Variables (For API Keys)

AISuite needs **API keys** to authenticate with providers. These are typically set via environment variables:

```bash
# .env file
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=...
AZURE_OPENAI_API_KEY=...
```

```python
from dotenv import load_dotenv
import aisuite as ai

load_dotenv()  # Loads API keys from .env

client = ai.Client()  # Automatically uses API keys from environment

# AISuite uses the appropriate API key based on the model provider
response = client.chat.completions.create(
    model="openai:gpt-4o",  # Uses OPENAI_API_KEY
    messages=[{"role": "user", "content": "Hello"}]
)
```

## How AISuite Routes to Different Providers

AISuite acts as a **unified interface** across multiple LLM providers:

```
Your Code
    ↓
ai.Client()
    ↓
model="openai:gpt-4o" → OpenAI API → GPT-4o
model="anthropic:claude-3-5-sonnet-20241022" → Anthropic API → Claude
model="google:gemini-1.5-pro" → Google API → Gemini
```

### Behind the Scenes

```python
# When you call:
response = client.chat.completions.create(
    model="openai:gpt-4o",
    messages=[...]
)

# AISuite:
# 1. Parses "openai:gpt-4o" → provider="openai", model="gpt-4o"
# 2. Looks up OPENAI_API_KEY from environment
# 3. Translates your request to OpenAI's API format
# 4. Makes HTTP request to OpenAI
# 5. Translates OpenAI's response back to standard format
# 6. Returns unified response object
```

## Example: Using Multiple Providers

```python
import aisuite as ai
from dotenv import load_dotenv

load_dotenv()
client = ai.Client()

# Use OpenAI
response1 = client.chat.completions.create(
    model="openai:gpt-4o",
    messages=[{"role": "user", "content": "What is 2+2?"}]
)

# Use Anthropic
response2 = client.chat.completions.create(
    model="anthropic:claude-3-5-sonnet-20241022",
    messages=[{"role": "user", "content": "What is 2+2?"}]
)

# Use Google
response3 = client.chat.completions.create(
    model="google:gemini-1.5-pro",
    messages=[{"role": "user", "content": "What is 2+2?"}]
)

# All responses have the same structure!
print(response1.choices[0].message.content)
print(response2.choices[0].message.content)
print(response3.choices[0].message.content)
```

## In the Refactored [ToolClient](cci:2://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/client.py:20:0-221:23)

Looking at our refactored code:

```python
# tool_use/client.py
class ToolClient:
    def __init__(self, model: str = "openai:gpt-4o"):
        self.client = ai.Client()
        self.default_model = model  # Store default model
        
    def chat(self, prompt: str, tools=None, model=None, max_turns=5):
        # Use provided model or fall back to default
        model = model or self.default_model
        
        response = self.client.chat.completions.create(
            model=model,  # ← Specified here
            messages=[{"role": "user", "content": prompt}],
            tools=tools,
            max_turns=max_turns
        )
        return response
```

**Usage:**

```python
from tool_use import ToolClient

# Option 1: Set default model at initialization
client = ToolClient(model="openai:gpt-4o")
response = client.chat(prompt="Hello")  # Uses gpt-4o

# Option 2: Override per call
client = ToolClient(model="openai:gpt-4o")
response = client.chat(
    prompt="Hello",
    model="anthropic:claude-3-5-sonnet-20241022"  # Override
)
```

## Common Model Identifiers

### OpenAI
```python
"openai:gpt-4o"              # Latest GPT-4 Optimized
"openai:gpt-4o-mini"         # Smaller, faster GPT-4
"openai:gpt-4-turbo"         # GPT-4 Turbo
"openai:gpt-3.5-turbo"       # GPT-3.5
"openai:o1-preview"          # Reasoning model
"openai:o1-mini"             # Smaller reasoning model
```

### Anthropic
```python
"anthropic:claude-3-5-sonnet-20241022"  # Claude 3.5 Sonnet
"anthropic:claude-3-opus-20240229"      # Claude 3 Opus
"anthropic:claude-3-sonnet-20240229"    # Claude 3 Sonnet
"anthropic:claude-3-haiku-20240307"     # Claude 3 Haiku
```

### Google
```python
"google:gemini-1.5-pro"      # Gemini 1.5 Pro
"google:gemini-1.5-flash"    # Gemini 1.5 Flash
```

### Azure OpenAI
```python
"azure:gpt-4"                # Requires additional Azure config
"azure:gpt-35-turbo"
```

## Configuration Example

**Complete setup:**

```python
# .env file
OPENAI_API_KEY=sk-proj-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=...

# Python code
from dotenv import load_dotenv
import aisuite as ai

load_dotenv()

client = ai.Client()

# Now you can use any provider
response = client.chat.completions.create(
    model="openai:gpt-4o",  # Specify which LLM here
    messages=[{"role": "user", "content": "Hello"}]
)
```

## Summary

**How AISuite knows which LLM to call:**

1. ✅ **You specify it** in the `model` parameter: `model="openai:gpt-4o"`
2. ✅ **Format**: `"provider:model-name"`
3. ✅ **API keys** come from environment variables
4. ✅ **AISuite routes** to the correct provider based on the prefix
5. ✅ **Unified interface** means same code works across providers

**Key Point**: 
```python
client = ai.Client()  # ← Doesn't specify model

# Model is specified HERE ↓
response = client.chat.completions.create(
    model="openai:gpt-4o",  # ← This is where you tell it which LLM
    messages=[...]
)
```

The `ai.Client()` is just the interface. The actual LLM is chosen when you make the API call via the `model` parameter!