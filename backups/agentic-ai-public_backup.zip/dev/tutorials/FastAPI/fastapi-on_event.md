Excellent question! You're asking about the **mechanism** behind how FastAPI knows to run this function. Let me explain the internals:

## How `@app.on_event("startup")` Works

### 1. **FastAPI's Event System**

FastAPI has a built-in **event registry** that stores functions to run at specific lifecycle points. When you use the decorator, you're **registering** your function with FastAPI.

### 2. **What Happens When You Write the Decorator**

```python
@app.on_event("startup")
def preload_emails():
    # ...
```

**Step-by-step:**

```python
# 1. You define the function
def preload_emails():
    db = SessionLocal()
    # ...

# 2. The decorator wraps it
@app.on_event("startup")
# This is equivalent to:
preload_emails = app.on_event("startup")(preload_emails)

# 3. FastAPI stores it internally
# Roughly: app._startup_handlers.append(preload_emails)
```

### 3. **Inside FastAPI's Code**

Here's a simplified version of what FastAPI does internally:

```python
class FastAPI:
    def __init__(self):
        self._startup_handlers = []    # List of startup functions
        self._shutdown_handlers = []   # List of shutdown functions
    
    def on_event(self, event_type: str):
        """Decorator to register event handlers"""
        def decorator(func):
            if event_type == "startup":
                self._startup_handlers.append(func)
            elif event_type == "shutdown":
                self._shutdown_handlers.append(func)
            else:
                raise ValueError(f"Unknown event: {event_type}")
            return func
        return decorator
    
    async def startup(self):
        """Called by uvicorn when server starts"""
        for handler in self._startup_handlers:
            if asyncio.iscoroutinefunction(handler):
                await handler()
            else:
                handler()  # Run sync functions directly
    
    async def shutdown(self):
        """Called by uvicorn when server stops"""
        for handler in self._shutdown_handlers:
            if asyncio.iscoroutinefunction(handler):
                await handler()
            else:
                handler()
```

### 4. **The Complete Flow**

```
1. Python imports your file (email_service.py)
   ↓
2. Encounters decorator:
   @app.on_event("startup")
   def preload_emails():
       ...
   ↓
3. Calls app.on_event("startup")
   - Returns a decorator function
   ↓
4. Decorator wraps preload_emails
   - Adds preload_emails to app._startup_handlers list
   - Returns the original function (unchanged)
   ↓
5. uvicorn starts the server
   ↓
6. uvicorn calls app.startup()
   ↓
7. FastAPI iterates through app._startup_handlers
   ↓
8. Runs each registered function:
   - preload_emails()
   - any_other_startup_function()
   ↓
9. Server is ready to accept requests
```

### 5. **Who Matches the "startup" Keyword?**

**Answer: FastAPI's `on_event()` method matches it!**

```python
def on_event(self, event_type: str):
    """
    event_type: The string you pass ("startup" or "shutdown")
    """
    def decorator(func):
        # This is where the matching happens:
        if event_type == "startup":
            # Store in startup handlers list
            self._startup_handlers.append(func)
        elif event_type == "shutdown":
            # Store in shutdown handlers list
            self._shutdown_handlers.append(func)
        else:
            # Invalid event type
            raise ValueError(f"Unknown event type: {event_type}")
        return func
    return decorator
```

### 6. **Valid Event Types**

FastAPI only recognizes two event types:

```python
@app.on_event("startup")    # ✅ Valid - runs on server start
def on_startup():
    print("Server starting!")

@app.on_event("shutdown")   # ✅ Valid - runs on server stop
def on_shutdown():
    print("Server stopping!")

@app.on_event("request")    # ❌ Invalid - not a recognized event
def on_request():
    pass  # This will raise an error!
```

### 7. **Multiple Event Handlers**

You can register **multiple** functions for the same event:

```python
@app.on_event("startup")
def setup_database():
    print("Setting up database...")

@app.on_event("startup")
def load_ml_model():
    print("Loading ML model...")

@app.on_event("startup")
def preload_emails():
    print("Preloading emails...")
```

**Execution order:**
```
1. uvicorn starts
   ↓
2. FastAPI runs all startup handlers in order:
   - setup_database()      → "Setting up database..."
   - load_ml_model()       → "Loading ML model..."
   - preload_emails()      → "Preloading emails..."
   ↓
3. Server ready
```

### 8. **The Uvicorn Connection**

Uvicorn (the ASGI server) is what actually **triggers** these events:

```python
# Simplified uvicorn code
class Server:
    def __init__(self, app):
        self.app = app
    
    async def startup(self):
        """Called when uvicorn starts"""
        # Uvicorn calls FastAPI's startup
        await self.app.startup()
    
    async def shutdown(self):
        """Called when uvicorn stops"""
        # Uvicorn calls FastAPI's shutdown
        await self.app.shutdown()
    
    async def run(self):
        await self.startup()      # ← Triggers @app.on_event("startup")
        # ... handle requests ...
        await self.shutdown()     # ← Triggers @app.on_event("shutdown")
```

### 9. **Visual Diagram**

```
┌─────────────────────────────────────────────────────────┐
│ Your Code: email_service.py                            │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  @app.on_event("startup")                              │
│  def preload_emails():                                 │
│      # ... load emails ...                             │
│                                                         │
└────────────────┬────────────────────────────────────────┘
                 │ Registers function
                 ↓
┌─────────────────────────────────────────────────────────┐
│ FastAPI Internal Registry                              │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  _startup_handlers = [                                 │
│      preload_emails,                                   │
│      # ... other startup functions ...                 │
│  ]                                                      │
│                                                         │
│  _shutdown_handlers = [                                │
│      # ... shutdown functions ...                      │
│  ]                                                      │
│                                                         │
└────────────────┬────────────────────────────────────────┘
                 │ Uvicorn triggers
                 ↓
┌─────────────────────────────────────────────────────────┐
│ Uvicorn Server Lifecycle                               │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  1. Server starts                                      │
│     ↓                                                   │
│  2. Call app.startup()                                 │
│     ↓                                                   │
│  3. FastAPI runs all _startup_handlers                 │
│     - preload_emails() ✅                              │
│     ↓                                                   │
│  4. Server accepts requests                            │
│     ↓                                                   │
│  5. Ctrl+C pressed                                     │
│     ↓                                                   │
│  6. Call app.shutdown()                                │
│     ↓                                                   │
│  7. FastAPI runs all _shutdown_handlers                │
│     ↓                                                   │
│  8. Server stops                                       │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 10. **Modern Alternative: Lifespan**

FastAPI now recommends using the newer **lifespan** pattern instead of `on_event`:

```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup code
    print("Server starting...")
    db = SessionLocal()
    try:
        # Preload emails
        db.execute(delete(Email))
        db.commit()
        # ... load sample emails ...
    finally:
        db.close()
    
    yield  # Server runs here
    
    # Shutdown code
    print("Server stopping...")
    # Cleanup resources

app = FastAPI(lifespan=lifespan)
```

**Benefits:**
- More explicit control flow
- Better resource management
- Async/await support
- Single place for startup/shutdown logic

### 11. **Testing the Event System**

You can verify the order of execution:

```python
@app.on_event("startup")
def first_startup():
    print("1. First startup handler")

@app.on_event("startup")
def second_startup():
    print("2. Second startup handler")

@app.on_event("startup")
def preload_emails():
    print("3. Preloading emails...")
    # ... actual preload code ...

@app.on_event("shutdown")
def cleanup():
    print("Cleaning up resources...")
```

**When you start the server:**
```bash
uvicorn email_service:app --reload
```

**Console output:**
```
1. First startup handler
2. Second startup handler
3. Preloading emails...
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete.
```

**When you stop (Ctrl+C):**
```
^C
Cleaning up resources...
INFO:     Shutting down
```

### Summary

**Who matches "startup"?**
- **FastAPI's `on_event()` method** checks the string
- It uses a simple `if event_type == "startup"` check
- Stores your function in an internal list
- **Uvicorn** triggers the event by calling `app.startup()`
- FastAPI then runs all registered startup handlers

**The chain:**
```
Your decorator → FastAPI registry → Uvicorn trigger → Function execution
```

It's a classic **observer pattern** - you register callbacks, and the framework calls them at the right time! 🎯