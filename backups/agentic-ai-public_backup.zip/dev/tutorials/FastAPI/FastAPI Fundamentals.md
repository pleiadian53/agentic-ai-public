Excellent question! Let me break down FastAPI's syntax and patterns for you. This is a great opportunity to understand how modern Python web frameworks work.

## FastAPI Fundamentals

### 1. **Decorators: The Core Pattern**

FastAPI uses Python **decorators** to define routes and behaviors:

```python
@app.something
def function_name():
    ...
```

The `@` symbol means: "Wrap this function with special behavior"

### 2. **Event Handlers: `@app.on_event()`**

```python
@app.on_event("startup")
def preload_emails():
    db = SessionLocal()
    try:
        db.execute(delete(Email))
        db.commit()
        # ... create sample emails ...
    finally:
        db.close()
```

**What this means:**
- `@app.on_event("startup")` → "Run this function when the server starts"
- Happens **once** when uvicorn starts
- Perfect for initialization tasks (database setup, loading data, etc.)

**Other events:**
```python
@app.on_event("startup")
def on_startup():
    print("Server is starting!")

@app.on_event("shutdown")
def on_shutdown():
    print("Server is shutting down!")
```

**Lifecycle:**
```
1. uvicorn starts
   ↓
2. @app.on_event("startup") executes
   ↓
3. Server ready to accept requests
   ↓
4. Handle requests...
   ↓
5. Server shutdown signal (Ctrl+C)
   ↓
6. @app.on_event("shutdown") executes
   ↓
7. Server stops
```

### 3. **HTTP Route Decorators**

FastAPI provides decorators for each HTTP method:

#### **GET Request**
```python
@app.get("/emails")
def list_emails(db: Session = Depends(get_db)):
    return db.query(Email).all()
```

**Breakdown:**
- `@app.get("/emails")` → Handle GET requests to `/emails`
- URL: `http://localhost:8000/emails`
- Returns: List of all emails

#### **POST Request**
```python
@app.post("/send", response_model=EmailOut)
def send_email(email: EmailCreate, db: Session = Depends(get_db)):
    new_email = Email(
        recipient=email.recipient,
        subject=email.subject,
        body=email.body,
        sender="you@mail.com",
    )
    db.add(new_email)
    db.commit()
    db.refresh(new_email)
    return new_email
```

**Breakdown:**
- `@app.post("/send")` → Handle POST requests to `/send`
- `response_model=EmailOut` → Validate and serialize response
- `email: EmailCreate` → Automatically parse JSON body into EmailCreate object
- `db: Session = Depends(get_db)` → Dependency injection (explained below)

#### **PATCH Request**
```python
@app.patch("/emails/{id}/read")
def mark_as_read(id: int, db: Session = Depends(get_db)):
    email = db.query(Email).filter(Email.id == id).first()
    if email:
        email.read = True
        db.commit()
    return email
```

**Breakdown:**
- `@app.patch("/emails/{id}/read")` → Handle PATCH to `/emails/123/read`
- `{id}` → Path parameter (captured from URL)
- `id: int` → Automatically converted to integer

#### **DELETE Request**
```python
@app.delete("/emails/{id}")
def delete_email(id: int, db: Session = Depends(get_db)):
    email = db.query(Email).filter(Email.id == id).first()
    if email:
        db.delete(email)
        db.commit()
    return {"message": "Email deleted"}
```

### 4. **Path Parameters: `{variable}`**

```python
@app.get("/emails/{id}")
def get_email(id: int, db: Session = Depends(get_db)):
    return db.query(Email).filter(Email.id == id).first()
```

**How it works:**
```
Request: GET /emails/42
         ↓
FastAPI extracts: id = 42
         ↓
Converts to int: id: int
         ↓
Calls: get_email(id=42, db=...)
```

**Multiple path parameters:**
```python
@app.get("/users/{user_id}/emails/{email_id}")
def get_user_email(user_id: int, email_id: int):
    return f"User {user_id}, Email {email_id}"
```

### 5. **Query Parameters**

```python
@app.get("/emails/search")
def search_emails(q: str, db: Session = Depends(get_db)):
    return db.query(Email).filter(
        Email.subject.contains(q) | Email.body.contains(q)
    ).all()
```

**How it works:**
```
Request: GET /emails/search?q=lunch
         ↓
FastAPI extracts: q = "lunch"
         ↓
Calls: search_emails(q="lunch", db=...)
```

**Optional query parameters:**
```python
@app.get("/emails")
def list_emails(
    limit: int = 10,           # Default value
    offset: int = 0,
    unread_only: bool = False
):
    # ...
```

### 6. **Request Body: Pydantic Models**

Perfect! Now let me explain how these work together:

```python
@app.post("/send", response_model=EmailOut)
def send_email(email: EmailCreate, db: Session = Depends(get_db)):
    # email is automatically validated and parsed!
    new_email = Email(
        recipient=email.recipient,
        subject=email.subject,
        body=email.body,
        sender="you@mail.com",
    )
    db.add(new_email)
    db.commit()
    db.refresh(new_email)
    return new_email  # Automatically serialized to EmailOut format
```

**What happens:**

```
1. Client sends POST request:
   {
     "recipient": "test@example.com",
     "subject": "Hello",
     "body": "Test message"
   }
   ↓
2. FastAPI validates against EmailCreate schema:
   - recipient: Must be valid email
   - subject: Must be string
   - body: Must be string
   ↓
3. If valid, creates EmailCreate object:
   email = EmailCreate(
       recipient="test@example.com",
       subject="Hello",
       body="Test message"
   )
   ↓
4. Calls your function: send_email(email=..., db=...)
   ↓
5. Your function returns Email object
   ↓
6. FastAPI serializes using EmailOut schema
   ↓
7. Client receives JSON response:
   {
     "id": 7,
     "sender": "you@mail.com",
     "recipient": "test@example.com",
     "subject": "Hello",
     "body": "Test message",
     "timestamp": "2025-11-05T...",
     "read": false
   }
```

**Benefits:**
- ✅ Automatic validation
- ✅ Type safety
- ✅ Auto-generated API docs
- ✅ Clear error messages

### 7. **Dependency Injection: `Depends()`**

This is one of FastAPI's most powerful features!

```python
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/emails")
def list_emails(db: Session = Depends(get_db)):
    return db.query(Email).all()
```

**How it works:**

```
1. Request comes in: GET /emails
   ↓
2. FastAPI sees: db: Session = Depends(get_db)
   ↓
3. Calls get_db() to get a database session:
   - Opens connection
   - Yields db object
   ↓
4. Injects db into your function:
   list_emails(db=<Session object>)
   ↓
5. Your function executes
   ↓
6. After function returns, get_db() cleanup runs:
   - Closes connection
   - Releases resources
```

**Why use Depends()?**

**Without Depends (manual):**
```python
@app.get("/emails")
def list_emails():
    db = SessionLocal()
    try:
        emails = db.query(Email).all()
        return emails
    finally:
        db.close()
```

**With Depends (automatic):**
```python
@app.get("/emails")
def list_emails(db: Session = Depends(get_db)):
    return db.query(Email).all()  # Cleanup happens automatically!
```

**Benefits:**
- ✅ Cleaner code
- ✅ Automatic cleanup
- ✅ Reusable dependencies
- ✅ Easy testing (can mock dependencies)

### 8. **Response Models**

```python
@app.post("/send", response_model=EmailOut)
def send_email(email: EmailCreate, db: Session = Depends(get_db)):
    # ...
    return new_email
```

**What `response_model=EmailOut` does:**

1. **Validates output** - Ensures your function returns correct data
2. **Filters fields** - Only includes fields defined in EmailOut
3. **Serializes** - Converts Python objects to JSON
4. **Documents API** - Auto-generates OpenAPI schema

**Example:**

```python
# Without response_model - returns everything
@app.get("/user/{id}")
def get_user(id: int):
    user = db.query(User).first()
    return user  # Includes password_hash! 😱

# With response_model - filters sensitive data
@app.get("/user/{id}", response_model=UserPublic)
def get_user(id: int):
    user = db.query(User).first()
    return user  # Only returns fields in UserPublic ✅
```

### 9. **Complete Example Walkthrough**

Let me trace a complete request through your email service:

```python
@app.post("/send", response_model=EmailOut)
def send_email(email: EmailCreate, db: Session = Depends(get_db)):
    new_email = Email(
        recipient=email.recipient,
        subject=email.subject,
        body=email.body,
        sender="you@mail.com",
    )
    db.add(new_email)
    db.commit()
    db.refresh(new_email)
    return new_email
```

**Step-by-step execution:**

```
1. Client request:
   POST http://localhost:8000/send
   Content-Type: application/json
   
   {
     "recipient": "alice@work.com",
     "subject": "Meeting",
     "body": "Let's meet tomorrow"
   }

2. FastAPI receives request
   ↓
3. Validates JSON against EmailCreate schema:
   ✅ recipient is valid email
   ✅ subject is string
   ✅ body is string
   ↓
4. Creates EmailCreate object:
   email = EmailCreate(
       recipient="alice@work.com",
       subject="Meeting",
       body="Let's meet tomorrow"
   )
   ↓
5. Resolves dependencies:
   - Calls get_db()
   - Gets database session
   ↓
6. Calls your function:
   send_email(
       email=<EmailCreate object>,
       db=<Session object>
   )
   ↓
7. Your function executes:
   - Creates Email model instance
   - Adds to database
   - Commits transaction
   - Refreshes to get ID and timestamp
   ↓
8. Function returns Email object
   ↓
9. FastAPI serializes using EmailOut:
   - Extracts: id, sender, recipient, subject, body, timestamp, read
   - Converts to JSON
   ↓
10. Dependency cleanup:
    - get_db() finally block runs
    - Closes database connection
    ↓
11. Client receives response:
    HTTP 200 OK
    Content-Type: application/json
    
    {
      "id": 8,
      "sender": "you@mail.com",
      "recipient": "alice@work.com",
      "subject": "Meeting",
      "body": "Let's meet tomorrow",
      "timestamp": "2025-11-06T01:59:00.123456",
      "read": false
    }
```

### 10. **Testing Your Understanding**

Try these curl commands to see FastAPI in action:

```bash
# 1. GET with no parameters
curl http://localhost:8000/emails

# 2. GET with path parameter
curl http://localhost:8000/emails/1

# 3. GET with query parameter
curl "http://localhost:8000/emails/search?q=lunch"

# 4. POST with JSON body
curl -X POST http://localhost:8000/send \
  -H "Content-Type: application/json" \
  -d '{
    "recipient": "test@example.com",
    "subject": "Test",
    "body": "Hello World"
  }'

# 5. PATCH to update
curl -X PATCH http://localhost:8000/emails/1/read

# 6. DELETE
curl -X DELETE http://localhost:8000/emails/1
```

### 11. **Auto-Generated Documentation**

FastAPI automatically creates interactive API docs! Visit:

- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

You can test all endpoints directly from the browser! 🎉

### 12. **Common Patterns Summary**

```python
# Event handlers
@app.on_event("startup")
def on_startup():
    """Runs once when server starts"""

# HTTP methods
@app.get("/path")           # Read
@app.post("/path")          # Create
@app.put("/path/{id}")      # Update (full)
@app.patch("/path/{id}")    # Update (partial)
@app.delete("/path/{id}")   # Delete

# Path parameters
@app.get("/items/{item_id}")
def get_item(item_id: int):
    """item_id extracted from URL"""

# Query parameters
@app.get("/items")
def list_items(skip: int = 0, limit: int = 10):
    """?skip=0&limit=10"""

# Request body
@app.post("/items")
def create_item(item: ItemCreate):
    """JSON body validated against ItemCreate"""

# Response model
@app.get("/items/{id}", response_model=ItemOut)
def get_item(id: int):
    """Response validated against ItemOut"""

# Dependencies
@app.get("/items")
def list_items(db: Session = Depends(get_db)):
    """db injected automatically"""
```

### Summary

FastAPI's syntax is all about:
1. **Decorators** - Define routes and behaviors
2. **Type hints** - Enable automatic validation
3. **Pydantic models** - Structure and validate data
4. **Dependency injection** - Share resources cleanly
5. **Automatic docs** - Generated from your code

The beauty is that FastAPI does the heavy lifting (validation, serialization, docs) while you focus on business logic! 🚀



---

> The `/path` syntax is FastAPI's way of saying "this is the URL route where this function will be accessible ...
>
> 

---

Great question! **No, `/path` is NOT a file path** - it's a **URL path** (also called a route or endpoint). Let me clarify this important distinction:

## URL Paths vs File Paths

### URL Path (What FastAPI Uses)

```python
@app.get("/emails")
def list_emails():
    return [...]
```

This creates a **web endpoint** accessible at:
```
http://localhost:8000/emails
                      ↑
                      This is the URL path
```

**Not related to files!** It's just a string that defines where clients can access your API.

### Real Examples from Your Code

```python
@app.get("/emails")                    # URL: http://localhost:8000/emails
@app.get("/emails/search")             # URL: http://localhost:8000/emails/search
@app.get("/emails/{id}")               # URL: http://localhost:8000/emails/42
@app.post("/send")                     # URL: http://localhost:8000/send
@app.patch("/emails/{id}/read")        # URL: http://localhost:8000/emails/42/read
@app.delete("/emails/{id}")            # URL: http://localhost:8000/emails/42
```

## Understanding URL Paths

### 1. **They're Just Strings**

```python
@app.get("/hello")
@app.get("/api/v1/users")
@app.get("/products/electronics/laptops")
@app.get("/🚀/emoji")  # Even emojis work!
```

All valid! The "path" is just part of the URL structure.

### 2. **URL Structure Breakdown**

```
http://localhost:8000/emails/search?q=lunch
│      │         │    │             │
│      │         │    │             └─ Query string
│      │         │    └─ URL path (the route)
│      │         └─ Port
│      └─ Host
└─ Protocol
```

### 3. **Path Segments**

The `/` separates logical segments:

```python
@app.get("/api/v1/users/123/posts/456")
          │   │  │     │   │     │
          │   │  │     │   │     └─ Post ID
          │   │  │     │   └─ Resource: posts
          │   │  │     └─ User ID
          │   │  └─ Resource: users
          │   └─ Version
          └─ Namespace
```

### 4. **Path Parameters (Dynamic Segments)**

```python
@app.get("/emails/{id}")
def get_email(id: int):
    # id is extracted from the URL
    pass
```

**Examples:**
```
GET /emails/1    → id = 1
GET /emails/42   → id = 42
GET /emails/999  → id = 999
```

The `{id}` is a **placeholder** that captures whatever value is in that position.

### 5. **Comparison: URL Path vs File Path**

| Aspect        | URL Path            | File Path                   |
| ------------- | ------------------- | --------------------------- |
| **Purpose**   | Route HTTP requests | Locate files on disk        |
| **Example**   | `/emails/search`    | `/Users/name/file.txt`      |
| **Separator** | `/` (always)        | `/` (Unix) or `\` (Windows) |
| **Context**   | Web/API             | Filesystem                  |
| **Dynamic?**  | Yes (`{id}`)        | No                          |

### 6. **Common Patterns**

#### RESTful Resource Naming
```python
# Collection
@app.get("/emails")           # List all emails
@app.post("/emails")          # Create new email

# Individual resource
@app.get("/emails/{id}")      # Get specific email
@app.put("/emails/{id}")      # Update email (full)
@app.patch("/emails/{id}")    # Update email (partial)
@app.delete("/emails/{id}")   # Delete email

# Sub-resources
@app.get("/emails/{id}/attachments")
@app.post("/emails/{id}/reply")
```

#### Nested Resources
```python
@app.get("/users/{user_id}/emails")
@app.get("/users/{user_id}/emails/{email_id}")
```

#### Actions
```python
@app.patch("/emails/{id}/read")      # Mark as read
@app.patch("/emails/{id}/unread")    # Mark as unread
@app.post("/emails/{id}/forward")    # Forward email
```

### 7. **Why It Looks Like a File Path**

The `/` notation comes from **URL standards** (RFC 3986), which borrowed from Unix file paths for familiarity. But they're conceptually different:

**File Path:**
```python
# Actually accesses a file on disk
with open("/Users/pleiadian53/data/emails.txt") as f:
    content = f.read()
```

**URL Path:**
```python
# Just a route identifier, no file involved
@app.get("/users/emails")
def get_emails():
    return db.query(Email).all()  # Data from database, not files!
```

### 8. **Your Email Service Routes**

Let me map out all your routes:

```python
# Root - serves UI
@app.get("/")
# → http://localhost:8000/

# Email operations
@app.get("/emails")
# → http://localhost:8000/emails

@app.get("/emails/unread")
# → http://localhost:8000/emails/unread

@app.get("/emails/search")
# → http://localhost:8000/emails/search?q=keyword

@app.get("/emails/{id}")
# → http://localhost:8000/emails/42

@app.post("/send")
# → http://localhost:8000/send

@app.patch("/emails/{id}/read")
# → http://localhost:8000/emails/42/read

@app.patch("/emails/{id}/unread")
# → http://localhost:8000/emails/42/unread

@app.delete("/emails/{id}")
# → http://localhost:8000/emails/42

@app.get("/reset_database")
# → http://localhost:8000/reset_database
```

### 9. **Testing URL Paths**

```bash
# These are URL paths, not file paths!
curl http://localhost:8000/emails              # ✅ URL path
curl http://localhost:8000/emails/search?q=hi  # ✅ URL path
curl http://localhost:8000/emails/42           # ✅ URL path

# This would be a file path (different!)
cat /Users/pleiadian53/work/emails.txt         # ✅ File path
```

### 10. **Key Takeaways**

1. **URL paths are routes** - They define where your API is accessible
2. **Not file paths** - No connection to your filesystem
3. **Just strings** - Can be anything (within URL rules)
4. **RESTful convention** - Use nouns for resources, verbs via HTTP methods
5. **Dynamic segments** - Use `{variable}` to capture values

### Summary

```python
@app.get("/emails")
         ↑
         This is a URL path (route)
         NOT a file path!
         
# It means: "When someone makes a GET request to 
# http://localhost:8000/emails, run this function"

# It does NOT mean: "Read from file /emails"
```

The `/path` syntax is FastAPI's way of saying "this is the URL route where this function will be accessible." Think of it as the **address** where your API function lives on the web! 🌐



---



---

Excellent question! The `email_id` comes from the **URL path** when a client makes a request. Let me break down exactly how this works:

## How Path Parameters Work

### 1. **The Route Definition**

```python
@app.patch("/emails/{email_id}/unread", response_model=EmailOut)
def mark_email_as_unread(email_id: int, db: Session = Depends(get_db)):
                         ↑
                         This parameter name must match
                         the {email_id} in the route
```

### 2. **Where `email_id` Comes From**

When a client makes a request, FastAPI **extracts** the value from the URL:

```
Client Request:
PATCH http://localhost:8000/emails/42/unread
                              ↑↑
                              This becomes email_id = 42

FastAPI sees the pattern:
/emails/{email_id}/unread
        ↑
        Captures "42" from this position

Then calls your function:
mark_email_as_unread(email_id=42, db=...)
```

### 3. **Step-by-Step Example**

```python
@app.patch("/emails/{email_id}/unread")
def mark_email_as_unread(email_id: int, db: Session = Depends(get_db)):
    print(f"Received email_id: {email_id}")
    # ...
```

**Request 1:**
```bash
curl -X PATCH http://localhost:8000/emails/5/unread
```
```
URL: /emails/5/unread
             ↑
FastAPI extracts: email_id = 5
Calls: mark_email_as_unread(email_id=5, db=...)
Prints: "Received email_id: 5"
```

**Request 2:**
```bash
curl -X PATCH http://localhost:8000/emails/123/unread
```
```
URL: /emails/123/unread
             ↑↑↑
FastAPI extracts: email_id = 123
Calls: mark_email_as_unread(email_id=123, db=...)
Prints: "Received email_id: 123"
```

### 4. **The Matching Rule**

The **parameter name** in your function must match the **placeholder name** in the route:

```python
# ✅ CORRECT - Names match
@app.patch("/emails/{email_id}/unread")
def mark_email_as_unread(email_id: int, ...):
                         ↑        ↑
                         These must be the same!

# ❌ WRONG - Names don't match
@app.patch("/emails/{email_id}/unread")
def mark_email_as_unread(id: int, ...):
                         ↑
                         FastAPI won't know where to get 'id'
```

### 5. **Multiple Path Parameters**

You can have multiple parameters in one route:

```python
@app.get("/users/{user_id}/emails/{email_id}")
def get_user_email(user_id: int, email_id: int):
    return f"User {user_id}, Email {email_id}"
```

**Request:**
```bash
curl http://localhost:8000/users/10/emails/42
```

**Extraction:**
```
URL: /users/10/emails/42
            ↑↑        ↑↑
user_id = 10    email_id = 42

Calls: get_user_email(user_id=10, email_id=42)
```

### 6. **Type Conversion**

FastAPI automatically converts the string from the URL to your specified type:

```python
@app.patch("/emails/{email_id}/unread")
def mark_email_as_unread(email_id: int, ...):
                                  ↑↑↑
                                  Type hint: int
```

**What happens:**
```
1. URL contains: "/emails/42/unread"
   ↓
2. FastAPI extracts: "42" (string)
   ↓
3. Sees type hint: int
   ↓
4. Converts: int("42") = 42
   ↓
5. Calls function with: email_id=42 (integer)
```

**If conversion fails:**
```bash
curl -X PATCH http://localhost:8000/emails/abc/unread
```

FastAPI returns error:
```json
{
  "detail": [
    {
      "loc": ["path", "email_id"],
      "msg": "value is not a valid integer",
      "type": "type_error.integer"
    }
  ]
}
```

### 7. **Complete Flow in Your Code**

```python
@app.patch("/emails/{email_id}/unread", response_model=EmailOut)
def mark_email_as_unread(email_id: int, db: Session = Depends(get_db)):
    email = db.query(Email).filter(Email.id == email_id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    email.read = False
    db.commit()
    db.refresh(email)
    return email
```

**Client makes request:**
```bash
curl -X PATCH http://localhost:8000/emails/7/unread
```

**Execution flow:**
```
1. Request arrives: PATCH /emails/7/unread
   ↓
2. FastAPI matches route: /emails/{email_id}/unread
   ↓
3. Extracts path parameter: email_id = 7
   ↓
4. Resolves dependencies: db = get_db()
   ↓
5. Calls function: mark_email_as_unread(email_id=7, db=<Session>)
   ↓
6. Function executes:
   - Queries database: Email.id == 7
   - Finds email with ID 7
   - Sets email.read = False
   - Commits to database
   ↓
7. Returns email object
   ↓
8. FastAPI serializes to EmailOut format
   ↓
9. Client receives JSON response
```

### 8. **Testing Different IDs**

```bash
# Mark email 1 as unread
curl -X PATCH http://localhost:8000/emails/1/unread

# Mark email 5 as unread
curl -X PATCH http://localhost:8000/emails/5/unread

# Mark email 999 as unread (doesn't exist)
curl -X PATCH http://localhost:8000/emails/999/unread
# Returns: {"detail": "Email not found"}
```

### 9. **Comparison with Other Parameters**

```python
@app.get("/emails/search")
def search_emails(
    q: str,                              # ← Query parameter (?q=value)
    limit: int = 10                      # ← Query parameter (?limit=10)
):
    pass

@app.get("/emails/{email_id}")
def get_email(
    email_id: int,                       # ← Path parameter (from URL)
    include_body: bool = True            # ← Query parameter (?include_body=true)
):
    pass

@app.post("/send")
def send_email(
    email: EmailCreate,                  # ← Request body (JSON)
    db: Session = Depends(get_db)        # ← Dependency injection
):
    pass
```

**How to call each:**
```bash
# Query parameters: after ?
GET /emails/search?q=lunch&limit=5

# Path parameters: in the URL path
GET /emails/42

# Mixed: path + query
GET /emails/42?include_body=false

# Request body: in POST/PATCH/PUT
POST /send
Content-Type: application/json
{"recipient": "...", "subject": "...", "body": "..."}
```

### 10. **Visual Summary**

```python
@app.patch("/emails/{email_id}/unread")
           ↑       ↑         ↑
           │       │         └─ Static part of URL
           │       └─ Dynamic part (captured)
           └─ Static part of URL

def mark_email_as_unread(email_id: int, ...):
                         ↑
                         Value comes from URL!
```

**Request-Response Cycle:**
```
Client                    FastAPI                     Your Function
  │                          │                             │
  ├─ PATCH /emails/7/unread ─→                            │
  │                          ├─ Parse URL                 │
  │                          ├─ Extract: email_id=7       │
  │                          ├─ Convert to int            │
  │                          ├─────────────────────────→  │
  │                          │                             ├─ Query DB for ID 7
  │                          │                             ├─ Update email.read=False
  │                          │                             ├─ Commit changes
  │                          │  ←─────────────────────────┤
  │                          ├─ Serialize to JSON         │
  │  ←─ 200 OK + JSON ───────┤                            │
  │                          │                             │
```

### Summary

**`email_id` comes from the URL path itself!**

- Route: `/emails/{email_id}/unread`
- Request: `PATCH /emails/42/unread`
- Result: `email_id = 42`

FastAPI automatically:
1. ✅ Extracts the value from the URL
2. ✅ Converts it to the specified type (`int`)
3. ✅ Passes it to your function
4. ✅ Validates it (returns error if invalid)

No manual parsing needed - FastAPI handles it all! 🎉





