Yes, you need to run `pip install -e .` (or `mamba run -n agentic-ai pip install -e .`) **every time you modify the entry points** in [pyproject.toml](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/pyproject.toml:0:0-0:0).

## When You Need to Reinstall

### ✅ **Required** - Changes to [pyproject.toml](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/pyproject.toml:0:0-0:0)

1. **Adding/removing/renaming CLI commands** in `[project.scripts]`
   ```toml
   [project.scripts]
   run-new-command = "scripts.new_script:main"  # ← Need reinstall
   ```

2. **Changing package metadata** (name, version, dependencies)
3. **Modifying package discovery settings** (`[tool.setuptools.packages.find]`)

### ❌ **Not Required** - Code Changes

1. **Editing existing Python files** (scripts, modules)
   - The `-e` (editable mode) means changes are immediately available
   - No reinstall needed!

2. **Adding new Python files** to existing packages
   - As long as the package structure doesn't change

3. **Modifying function implementations**

## Why This Happens

When you run `pip install -e .`, it:

1. **Reads [pyproject.toml](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/pyproject.toml:0:0-0:0)** to find entry points
2. **Creates wrapper scripts** in your environment's `bin/` directory
   - Example: `/Users/.../miniforge3-new/envs/agentic-ai/bin/run-reflection-research-agent`
3. **Links to your source code** (editable mode)

The wrapper scripts are **generated once** during installation, so changes to entry points require regeneration.

## Best Practice Workflow

```bash
# 1. Develop your script
vim scripts/run_new_agent.py

# 2. Test it directly (no install needed)
python scripts/run_new_agent.py --help

# 3. When ready, add to pyproject.toml
# Edit [project.scripts] section

# 4. Install to register CLI command
pip install -e .

# 5. Now use the CLI command
run-new-agent --help

# 6. Continue editing the script
# No reinstall needed for code changes!
vim scripts/run_new_agent.py
run-new-agent --help  # ← Uses latest code automatically
```

## Quick Check

To see if you need to reinstall:

```bash
# Check if command exists
which run-reflection-research-agent

# If it doesn't exist or points to wrong location
pip install -e .
```

## Summary

- **Entry point changes** (in [pyproject.toml](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/pyproject.toml:0:0-0:0)) → Reinstall required
- **Code changes** (in `.py` files) → No reinstall needed (editable mode handles it)

The `-e` flag is powerful because it means you can iterate on code without reinstalling, but the entry point wrappers themselves need to be regenerated when the configuration changes.