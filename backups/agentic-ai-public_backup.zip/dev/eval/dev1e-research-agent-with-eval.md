Great. Can you help me create a research agent package under eval/ by incorporating both tool_use/research_agent with the component-wise evaluation to potentially increase the quality of the final research report? 

You are free to start with copying and pasting the source code of the research agent under tool_use (if that helps). 

----

I'll create an enhanced research agent package under [eval/](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval:0:0-0:0) that integrates the research agent with component-wise evaluation. Let me start by examining the current research agent structure:

Now let me check the run_research_workflow:

Perfect! Now let me create an enhanced research agent package under [eval/](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval:0:0-0:0) that integrates component-wise evaluation. I'll create a new package structure:

Now let me create the main agent module with integrated evaluation:

Now let me create example scripts:

Now let me update the main eval package to export the new research agent:

Perfect! Now let me update the plan and create a final summary document:

Perfect! Let me create a final summary for you:

## ✅ Complete! Enhanced Research Agent with Integrated Evaluation

I've successfully created a comprehensive **Enhanced Research Agent** package under `eval/research_agent/` that combines the research agent from [tool_use/research_agent](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/research_agent:0:0-0:0) with component-wise evaluation to automatically improve research quality.

---

## 📦 What Was Created

### Package Structure

```
eval/research_agent/
├── __init__.py                    # Package exports
├── agent.py                       # EvaluatedResearchAgent class (600+ lines)
├── workflow.py                    # Complete workflow runner (300+ lines)
├── README.md                      # Comprehensive documentation (600+ lines)
├── INTEGRATION_SUMMARY.md         # Integration guide
└── examples/
    ├── basic_usage.py             # Simple example
    ├── complete_workflow.py       # Full workflow example
    └── quality_comparison.py      # Base vs. Evaluated comparison
```

---

## 🎯 Key Features

### 1. **Automatic Quality Improvement Loop**

```python
from eval.research_agent import EvaluatedResearchAgent

agent = EvaluatedResearchAgent(
    min_source_ratio=0.5,  # Require 50% from preferred domains
    max_retries=2          # Retry up to 2 times if quality is poor
)

results = agent.generate_report("quantum computing")

# Automatic evaluation and retry if quality is poor
print(f"Status: {results['evaluation'].status}")
print(f"Quality: {results['evaluation'].preferred_ratio:.1%}")
print(f"Retries needed: {results['retry_count']}")
```

**How it works:**
1. Generate research report
2. Evaluate source quality
3. If quality < threshold → Retry with improved prompt
4. Repeat until quality is acceptable or max retries reached

### 2. **Component-Wise Evaluation**

Evaluates sources at each step:
- ✅ After initial research
- ✅ After reflection/rewrite
- ✅ Tracks improvement across iterations

### 3. **Production Research Tools**

Uses enhanced tools from [eval/research_tools.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/research_tools.py:0:0-0:0):
- ✅ Retry logic with exponential backoff
- ✅ Wikipedia caching (10-100x faster)
- ✅ Extended search parameters
- ✅ Better error handling

### 4. **Reflection with Evaluation Context**

```python
reflection = agent.reflect_and_rewrite(
    report,
    evaluation=eval_result  # Includes source quality metrics
)
# Reflection now includes analysis of source quality
```

### 5. **Flexible Configuration**

```python
from eval import ACADEMIC_DOMAINS, BIOLOGY_FOCUSED_DOMAINS

# For scientific research
agent = EvaluatedResearchAgent(preferred_domains=ACADEMIC_DOMAINS)

# For biology/life sciences
agent = EvaluatedResearchAgent(preferred_domains=BIOLOGY_FOCUSED_DOMAINS)

# Custom threshold
agent = EvaluatedResearchAgent(min_source_ratio=0.7)  # Strict: 70%
```

---

## 🚀 Usage Examples

### Basic Usage

```python
from eval.research_agent import EvaluatedResearchAgent

agent = EvaluatedResearchAgent()
results = agent.generate_report("quantum computing")

print(f"Quality: {results['evaluation'].preferred_ratio:.1%}")
print(results['report'])
```

### Complete Workflow

```python
from eval.research_agent import run_evaluated_workflow
from eval import BIOLOGY_FOCUSED_DOMAINS

results = run_evaluated_workflow(
    topic="mRNA vaccine technology",
    preferred_domains=BIOLOGY_FOCUSED_DOMAINS,
    min_source_ratio=0.6,
    max_retries=2,
    run_reflection=True,
    generate_html=True
)

# Access comprehensive results
print(f"Initial quality: {results['evaluation'].preferred_ratio:.1%}")
print(f"Revised quality: {results['revised_evaluation'].preferred_ratio:.1%}")
print(f"Retries: {results['retry_count']}")
```

### Command-Line

```bash
# Basic
python -m eval.research_agent.workflow "quantum computing"

# With biology domains and high quality threshold
python -m eval.research_agent.workflow "CRISPR gene editing" \
    --domains biology \
    --min-ratio 0.6 \
    --max-retries 2

# Fast mode (skip reflection)
python -m eval.research_agent.workflow "AI safety" --no-reflection
```

---

## 📊 Comparison: Base vs. Evaluated Agent

| Feature                | Base Agent | Evaluated Agent    |
| ---------------------- | ---------- | ------------------ |
| **Source Evaluation**  | ❌ No       | ✅ Real-time        |
| **Quality Feedback**   | ❌ No       | ✅ Automatic retry  |
| **Metrics**            | ❌ No       | ✅ Comprehensive    |
| **Retry Logic**        | ❌ No       | ✅ Automatic        |
| **Domain Filtering**   | ❌ No       | ✅ Configurable     |
| **Reflection Context** | ⚠️ Basic    | ✅ With evaluation  |
| **Research Tools**     | ⚠️ Basic    | ✅ Production-ready |

---

## 🔄 The Evaluation Loop

```
Attempt 1:
  ├─ Generate research report
  ├─ Evaluate sources → 30% from preferred domains
  └─ Status: FAIL (below 50% threshold)

Attempt 2 (Retry with improved prompt):
  ├─ Add guidance: "Focus on academic sources from arxiv.org, nature.com..."
  ├─ Generate research report
  ├─ Evaluate sources → 55% from preferred domains
  └─ Status: PASS ✅

Continue workflow:
  ├─ Reflection (with evaluation feedback)
  ├─ Re-evaluate revised report → 60% preferred
  ├─ Convert to HTML
  └─ Save all outputs with metrics
```

---

## 📁 Output Files

The workflow generates:

```
evaluated_research_outputs/
├── 20241113_223045_topic_preliminary.txt          # Initial report
├── 20241113_223045_topic_evaluation.md            # Initial evaluation
├── 20241113_223045_topic_reflection.txt           # Reflection analysis
├── 20241113_223045_topic_revised.txt              # Revised report
├── 20241113_223045_topic_revised_evaluation.md    # Revised evaluation
└── 20241113_223045_topic_report.html              # Final HTML
```

---

## 🎓 Try It Out

### 1. Run Examples

```bash
# Basic usage
python eval/research_agent/examples/basic_usage.py

# Complete workflow
python eval/research_agent/examples/complete_workflow.py

# Quality comparison
python eval/research_agent/examples/quality_comparison.py
```

### 2. Run Your Own Research

```bash
python -m eval.research_agent.workflow "your research topic here"
```

### 3. Integrate into Your Code

```python
from eval.research_agent import EvaluatedResearchAgent
from eval import ACADEMIC_DOMAINS

agent = EvaluatedResearchAgent(
    preferred_domains=ACADEMIC_DOMAINS,
    min_source_ratio=0.5
)

results = agent.generate_report("your topic")
```

---

## 📚 Documentation

- **Main README**: [eval/research_agent/README.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/research_agent/README.md:0:0-0:0) (600+ lines)
- **Integration Summary**: [eval/research_agent/INTEGRATION_SUMMARY.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/research_agent/INTEGRATION_SUMMARY.md:0:0-0:0)
- **Examples**: `eval/research_agent/examples/`
- **Research Tools Guide**: [eval/RESEARCH_TOOLS_GUIDE.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/RESEARCH_TOOLS_GUIDE.md:0:0-0:0)
- **Evaluation Package**: [eval/README.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/README.md:0:0-0:0)

---

## ✨ Benefits

1. **Improved Research Quality**: Automatic retry ensures high-quality sources
2. **Transparency**: Comprehensive evaluation metrics
3. **Reduced Manual Work**: No manual source checking required
4. **Flexibility**: Configurable thresholds and domain sets
5. **Production-Ready**: Robust error handling and logging

---

## 🎯 Summary

The Enhanced Research Agent successfully integrates:

✅ **Research generation** from [tool_use/research_agent](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/tool_use/research_agent:0:0-0:0)  
✅ **Component-wise evaluation** from `eval/`  
✅ **Production research tools** from [eval/research_tools.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/research_tools.py:0:0-0:0)  
✅ **Automatic quality improvement** through retry logic  
✅ **Comprehensive metrics** and reporting  
✅ **Flexible configuration** for different domains  

**Result**: A production-ready research agent that automatically improves source quality and provides transparency through evaluation metrics! 🚀