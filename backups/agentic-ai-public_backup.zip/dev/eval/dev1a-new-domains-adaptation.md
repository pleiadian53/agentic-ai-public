<features> Domain adaptation
Focus more on Combio: 

@config.py#L1-24 

We'll be extending this project (agentic-ai-public) to later focus more specific domains like computational biology, bioinformatics, RNA therapeutics. Would you be able to help me search, identify and incorporate more of these subject-specific domains? 

---



@M4_UGL_1.ipynb Cell:4:16-20  in the notebook, the research tools module define callable functions for LLM: eval/M4/research_tools.py Why do you think it's necessary to also define a JSON like object (dictionary) for each function like this one@research_tools.py#L64-85 for arxiv_search_tool()? or do they serve different purposes?  Please also document this under eval/docs/ 

---

I'll help you identify and add domain-specific sources for computational biology, bioinformatics, and RNA therapeutics. Let me search for authoritative sources in these fields:



Perfect! Now let me create an enhanced config file with these domain-specific sources:

Now let me update the DEFAULT_PREFERRED_DOMAINS and add helper functions:

Now let me update the __init__.py to export the new categories:

Perfect! Now let me create a usage example document:

Perfect! The markdown lint warnings are minor formatting issues that don't affect functionality. Let me create a summary document:

## ✅ Complete! Biology-Specific Domains Added

I've successfully extended the evaluation package with comprehensive domain sets for computational biology, bioinformatics, RNA therapeutics, and genomics research.

### 📊 What Was Added

#### **New Domain Categories** (in [eval/config.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/config.py:0:0-0:0)):

1. **`COMPUTATIONAL_BIOLOGY_DOMAINS`** (~50 domains)
   - Journals: PLOS Comp Bio, Bioinformatics, NAR, BMC Bioinformatics, GigaScience
   - Databases: NCBI, EBI, Ensembl, UniProt, PDB, KEGG, Reactome, STRING
   - Resources: Bioconductor, BioCyc, GeneCards, OMIM

2. **`RNA_THERAPEUTICS_DOMAINS`** (~25 domains)
   - Specialized: RNA journal, Nucleic Acid Therapeutics, RNA Biology
   - Major journals: Cell, Nature, Science, NEJM
   - RNA databases: RNAcentral, miRBase, tRNA database
   - Clinical: ClinicalTrials.gov, FDA, EMA
   - Institutions: UMass RTI, Broad Institute, Sanger Institute

3. **`GENOMICS_DOMAINS`** (~15 domains)
   - Journals: Genome Biology, Genome Research, Genetics, Nature Genetics
   - Databases: gnomAD, 1000 Genomes, GTEx, ENCODE
   - Organizations: NHGRI, ASHG

4. **`BIOLOGY_FOCUSED_DOMAINS`** (~150+ domains)
   - Comprehensive set combining all biology categories

### 🎯 Usage Examples

**Quick Start:**
```python
from eval import DomainEvaluator, COMPUTATIONAL_BIOLOGY_DOMAINS

evaluator = DomainEvaluator(
    preferred_domains=COMPUTATIONAL_BIOLOGY_DOMAINS,
    min_ratio=0.6
)

result = evaluator.evaluate_text(research_output)
print(result.status)  # ✅ PASS or ❌ FAIL
```

**Using Helper Functions:**
```python
from eval import get_domain_set

# Get specific category
rna_domains = get_domain_set('rna_therapeutics')
bio_domains = get_domain_set('biology')  # All biology domains

# Create custom combination
from eval import create_custom_domain_set

my_domains = create_custom_domain_set(
    'computational_biology',
    'rna_therapeutics',
    extra_domains={'mylab.edu', 'specialized-journal.org'}
)
```

**Integration with Research Agent:**
```python
from tool_use.research_agent import generate_research_report_with_tools
from eval import DomainEvaluator, BIOLOGY_FOCUSED_DOMAINS

report = generate_research_report_with_tools("CRISPR mechanisms")

evaluator = DomainEvaluator(
    preferred_domains=BIOLOGY_FOCUSED_DOMAINS,
    min_ratio=0.6
)
result = evaluator.evaluate_text(report)
```

### 📚 Documentation

- **[eval/config.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/config.py:0:0-0:0)**: All domain definitions with inline comments
- **[eval/BIOLOGY_DOMAINS_GUIDE.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/BIOLOGY_DOMAINS_GUIDE.md:0:0-0:0)**: Comprehensive usage guide with examples
- **[eval/README.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/README.md:0:0-0:0)**: Already includes general usage (still valid)

### 🔍 Domain Sources

Based on authoritative sources:
- Wikipedia's list of bioinformatics journals
- UMass RNA Therapeutics Institute journal list
- Major databases: NCBI, EBI, UniProt, PDB
- Top-tier journals: Nature, Science, Cell, PNAS
- Clinical resources: FDA, EMA, ClinicalTrials.gov

### 🚀 Next Steps

1. **Test the new domains:**
   ```python
   from eval import COMPUTATIONAL_BIOLOGY_DOMAINS
   print(f"Total comp bio domains: {len(COMPUTATIONAL_BIOLOGY_DOMAINS)}")
   print('ncbi.nlm.nih.gov' in COMPUTATIONAL_BIOLOGY_DOMAINS)  # True
   ```

2. **Use in your research workflows:**
   ```python
   # For RNA therapeutics research
   evaluator = DomainEvaluator(
       preferred_domains=get_domain_set('rna_therapeutics'),
       min_ratio=0.7
   )
   ```

3. **Extend as needed:**
   - Add field-specific journals to [config.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/config.py:0:0-0:0)
   - Create custom combinations for your research area
   - Contribute back to the project!

The evaluation package is now fully equipped for life sciences research evaluation! 🧬🔬