TinyDB does persist data. By default, when you instantiate a database with something like `TinyDB("db.json")`, it stores every record in that JSON file on disk. Each time you insert, update, or remove entries, TinyDB rewrites the file to keep it in sync. Because the storage layer is pluggable, you can switch to other backends (e.g., an in-memory storage for tests or a custom storage class) by passing `storage=<CustomStorage>` when you create the `TinyDB` instance. So although the API feels like a lightweight document store, the data is durable across runs as long as you point it at a real file.

---

TinyDB is intentionally **non-SQL**: it exposes a simple document-store API where you query via Python expressions and `Query` objects rather than SQL strings. That makes it lightweight and easy for small apps, but it also means you don’t get relational features such as joins, transactions, or advanced indexing.

Compared to a relational database like **MySQL**:
- **Schema & joins**: TinyDB stores schemaless JSON documents; MySQL enforces schemas and supports joins across tables.
- **Transactions/concurrency**: TinyDB has no ACID transactions or multi-user locking; MySQL is built for concurrent, transactional workloads.
- **Indexes/performance**: TinyDB keeps everything in memory and re-writes the JSON file on updates, so datasets need to stay small; MySQL scales to large datasets with sophisticated indexing and query planners.

Compared to **SQLite**:
- SQLite is also file-based and serverless, but it is still a full SQL database with ACID guarantees, B-tree indexes, and transactional safety.
- TinyDB trades those features for simplicity: you interact with native Python objects, but you lose SQL expressiveness, complex queries, and reliability under higher write loads.
- If you need even lightweight SQL (filters, sorting, joins) or better durability, SQLite is usually the step up; TinyDB is best for prototyping, small config stores, or educational demos where a JSON-backed store is enough.