I'll help you find the differences between these two notebooks. Let me read both files and compare them.

# Differences Between M5_UGL_1_R.ipynb and M5_UGL_1.ipynb

I've analyzed both notebooks. Here are the key differences:

## 🎯 High-Level Approach

| Aspect              | M5_UGL_1_R.ipynb                     | M5_UGL_1.ipynb                         |
| ------------------- | ------------------------------------ | -------------------------------------- |
| **Architecture**    | **Single-agent** with code execution | **Multi-agent** with specialized roles |
| **Planning Method** | LLM writes Python code directly      | LLM generates JSON tool-call plans     |
| **Database**        | TinyDB (document store)              | DuckDB (SQL) with pandas DataFrames    |
| **Execution**       | Execute generated Python in sandbox  | Execute tool calls from registry       |
| **Validation**      | Embedded in Python code              | Separate validation tools              |

---

## 📋 Detailed Differences

### 1. **Core Philosophy**

**M5_UGL_1_R.ipynb** ("R" = Research/Raw):
- Implements Andrew's **"Code as Action"** pattern
- LLM generates **executable Python code** that IS the plan
- Code includes comments explaining each step
- Single function executes the entire workflow

**M5_UGL_1.ipynb**:
- Implements **multi-agent workflow** with specialized roles
- Uses **Planner → Reflection → Executor** pipeline
- Plans are **JSON structures** with tool calls
- Separate agents for planning, reviewing, and executing

### 2. **Data Storage**

**M5_UGL_1_R.ipynb**:
```python
# Uses TinyDB (JSON document store)
from tinydb import Query, where
db, inventory_tbl, transactions_tbl = inv_utils.seed_db()

# Query example
Item = Query()
round_sunglasses = inventory_tbl.search(
    (Item.description.test(lambda v: " round " in ((v or "").lower())))
)
```

**M5_UGL_1.ipynb**:
```python
# Uses DuckDB with pandas DataFrames
import duckdb
import pandas as pd

inventory_df = inventory_utils.create_inventory_dataframe()
transaction_df = inventory_utils.create_transaction_dataframe()

con = duckdb.connect()
con.register("inventory_df", inventory_df)
```

### 3. **Planning Approach**

**M5_UGL_1_R.ipynb** - Code Generation:
```python
# LLM generates Python code between tags
<execute_python>
# Step 1: Parse intent from user_request
# Step 2: Query inventory_tbl with TinyDB
# Step 3: If mutate, update tables
# Step 4: Set answer_text variable
</execute_python>
```

**M5_UGL_1.ipynb** - Tool-Based Planning:
```json
{
  "reasoning": "User requests a return...",
  "steps": [
    {
      "step_number": 1,
      "description": "Lookup product",
      "tools": [
        {"use": "get_inventory_data", "args": {"product_name": "Aviator"}, "result_key": "prod"}
      ],
      "validations": [
        {"name": "product_found", "use_tool": "assert_true", "args": {...}}
      ]
    }
  ]
}
```

### 4. **Execution Model**

**M5_UGL_1_R.ipynb**:
```python
def execute_generated_code(code_or_content, *, db, inventory_tbl, transactions_tbl):
    # Extract Python code from <execute_python> tags
    code = _extract_execute_block(code_or_content)
    
    # Execute in controlled namespace
    exec(code, SAFE_GLOBALS, SAFE_LOCALS)
    
    # Return answer_text set by code
    return {"answer": SAFE_LOCALS.get("answer_text"), ...}
```

**M5_UGL_1.ipynb**:
```python
def execute_plan_tools_only(plan, inventory_df, transaction_df):
    # Execute each step sequentially
    for step in plan["steps"]:
        # Run tools from registry
        ran = tools.run_tools_for_step(step, ctx)
        
        # Run validations
        validations = [tools.run_tool_validation(v, ctx) for v in step["validations"]]
        
        # Stop if validation fails
        if not all(v["ok"] for v in validations):
            break
```

### 5. **Workflow Structure**

**M5_UGL_1_R.ipynb** - Single Function:
```python
def customer_service_agent(question, *, db, inventory_tbl, transactions_tbl):
    # 1) Generate code
    full_content = generate_llm_code(question, ...)
    
    # 2) Execute code
    exec_res = execute_generated_code(full_content, ...)
    
    # 3) Return result
    return {"answer": exec_res["answer"], ...}
```

**M5_UGL_1.ipynb** - Multi-Step Pipeline:
```python
# 1) Planning step
draft_plan = generate_plan(user_prompt)

# 2) Reflection step
reflection = reflect_on_plan(user_prompt, draft_plan)
final_plan = reflection["revised_plan"]

# 3) Execution step
report = execute_plan_tools_only(final_plan, inventory_df, transaction_df)

# 4) Error explanation (if needed)
if not report["ok"]:
    explanation = explain_execution_error(user_prompt, report)
```

### 6. **Tool Registry**

**M5_UGL_1_R.ipynb**:
- No explicit tool registry
- Uses Python functions directly in generated code
- Helper functions: `get_current_balance()`, `next_transaction_id()`

**M5_UGL_1.ipynb**:
```python
# Explicit tool registry with 8 tools
TOOL_REGISTRY = {
    "get_inventory_data": ...,
    "get_transaction_data": ...,
    "compute_total": ...,
    "compute_refund": ...,
    "update_inventory": ...,
    "append_transaction": ...,
    "assert_true": ...,
    "assert_nonnegative_stock": ...
}
```

### 7. **Validation Strategy**

**M5_UGL_1_R.ipynb**:
- Validations embedded in generated Python code
- LLM decides validation logic
- Example: `if stock < 0: STATUS="insufficient_stock"`

**M5_UGL_1.ipynb**:
- Explicit validation tools in plan
- Separate validation phase after each step
- Example: `{"name": "stock_nonnegative", "use_tool": "assert_nonnegative_stock"}`

### 8. **Error Handling**

**M5_UGL_1_R.ipynb**:
```python
# LLM sets STATUS variable in code
STATUS = "success" | "no_match" | "insufficient_stock" | "invalid_request"
answer_text = "Human-friendly message"
```

**M5_UGL_1.ipynb**:
```python
# Execution report with detailed steps
report = {
    "ok": False,
    "aborted": True,
    "abort_step": 2,
    "abort_reason": "validation_failed"
}

# Separate error explanation step
explanation = explain_execution_error(user_prompt, report)
```

### 9. **Prompt Complexity**

**M5_UGL_1_R.ipynb**:
- Single large prompt (~100 lines)
- Includes: schema, execution rules, transaction policy, output contract
- LLM must generate complete Python solution

**M5_UGL_1.ipynb**:
- Multiple focused prompts:
  - Planning spec (~150 lines) - tool catalog and rules
  - Reflection prompt - critique and revision
  - Error explanation prompt - plain English summary

### 10. **Model Usage**

**M5_UGL_1_R.ipynb**:
```python
# Single model call for code generation
generate_llm_code(prompt, model="o4-mini", temperature=1.0)
```

**M5_UGL_1.ipynb**:
```python
# Multiple model calls in pipeline
draft_plan = generate_plan(user_prompt, model="o4-mini")
reflection = reflect_on_plan(user_prompt, draft_plan, model="o4-mini")
explanation = explain_execution_error(user_prompt, report, model="o4-mini")
```

---

## 🎓 Learning Objectives Comparison

### M5_UGL_1_R.ipynb Teaches:
- ✅ **Code as Action** pattern (Andrew's lecture concept)
- ✅ Why code is more expressive than JSON plans
- ✅ Safe code execution in sandboxes
- ✅ Single-agent workflow

### M5_UGL_1.ipynb Teaches:
- ✅ **Multi-agent coordination** (Planner, Reflector, Executor)
- ✅ Tool-based planning with registries
- ✅ Validation as separate concern
- ✅ Error explanation for failed executions
- ✅ Agentic workflow patterns

---

## 🔑 Key Takeaway

**M5_UGL_1_R.ipynb** is a **simpler, more direct** implementation where the LLM writes Python code that becomes the plan. It's closer to Andrew's "planning with code execution" lecture concept.

**M5_UGL_1.ipynb** is a **more structured, production-oriented** approach with multiple agents, explicit tool registries, and separation of concerns (planning → reflection → execution → error explanation).

Both solve the same problem (customer service for sunglasses store) but demonstrate **different architectural patterns** for agentic AI systems.



---

Utility functions for OpenAI API



---

```
from utils import display_models_table

api_key = os.environ.get("OPENAI_API_KEY")
if not api_key:
    raise RuntimeError("Missing OPENAI_API_KEY")

display_models_table(client.models.list())
```

---

Which model are we using in this notebook? 
---

In this notebook nothing “auto-selects” a model for you. The OpenAI Python client only uses whatever model string you pass each time you call it. To see which one you’re actually invoking:

```python
MODEL = "o4-mini"  # or gpt-4o, gpt-4.1, etc.

response = client.chat.completions.create(
    model=MODEL,
    messages=[...],
)
print(f"Using model: {MODEL}")
```

If you don’t set `model=...`, the API call fails—there is no hidden default.

To inspect what’s available (and confirm naming), use the helper we added earlier:

```python
from utils import display_models_table

display_models_table(client.models.list(), title="Available OpenAI Models")
```

That shows every model ID you can choose from. Pick one and assign it to a constant (or config), and log it when you make requests so you always know which model handled a given result.

---

`re.search()` , re.DOTALL? 

---



`re.search(r"<execute_python>(.*?)</execute_python>", text, re.DOTALL | re.IGNORECASE)` looks for the first `<execute_python> ... </execute_python>` block in `text`.*

- `re.IGNORECASE` lets the tag match in any case (e.g., `<Execute_Python>`).
- `re.DOTALL` makes the dot (`.`) also match newline characters, so the `.*?` portion can span multiple lines of code between the opening and closing tags. Without `DOTALL`, `.` would stop at a newline and the pattern wouldn’t capture multi-line code blocks.*

---

@M5_UGL_1_R.ipynb Cell:20:27-58 

This code block defines what can be executed in the enviornment but i think this is tedious. What if the code for the given plan is very complex and spans hundreds or even thousands of line? 

This is fine for educational and demo purposes. But, What would be a more elegant, SoA solution. 

---

Right—the notebook’s executor lets the LLM emit arbitrary Python inside `<execute_python>` tags, so we must explicitly constrain the namespace (SAFE_GLOBALS/SAFE_LOCALS), capture stdout, and collect outputs. For demos it’s fine, but in production you’d want a more robust approach:

1. **Use Restricted Sandboxes**: Instead of `exec`, run the code in a hardened environment (e.g., Pyodide, WASI, or a jailed microservice) with resource limits, timeouts, and syscall restrictions.
2. **Adopt Domain-Specific APIs**: Rather than letting the model write free-form Python, expose a curated set of functions (tools) and have the model produce structured plans (JSON) that reference them—like the multi-agent `M5_UGL_1.ipynb`. The executor then translates the plan into validated tool calls.
3. **Static Analysis or LLMSec**: If you keep code generation, enforce templates and run static checks before execution (disallow file/network operations, limit imports). Projects like OpenAI’s “Code Interpreter sandbox” or Guardrails frameworks illustrate this.
4. **Service-Oriented Execution**: Delegate mutations to backend services with clear APIs (e.g., “inventory.adjust_stock(item_id, delta)”). The LLM composes workflows using these APIs, while the services handle authentication, logging, and safety.
5. **Auditable Workflows**: Instead of capturing `answer_text` from locals, persist every step (plan, tool calls, inputs/outputs) into a run log or vector DB, enabling review, rollback, and chained retries.

In short: for educational purposes, `exec` with SAFE_GLOBALS works. For a production “state-of-the-art” solution, shift from arbitrary code execution toward structured plans + trusted toolchains (or managed sandboxes) so you get traceability, policy enforcement, and reduced attack surface.

---

Can you answer my previous question? GPT-5 answered it but it's too concise for me. 

One element of the question I asked was that what would be a less boilerplate code to achieve this because I don't want to have to manually keep track of what's safe to execute. 

---

For reducing boilerplate and avoiding manual tracking of "safe" namespaces, here are more elegant approaches:

## 1. **Declarative Tool Registry with Auto-Discovery**

Instead of manually listing every safe function in `SAFE_GLOBALS`, use a decorator-based registry:

```python
TOOL_REGISTRY = {}

def tool(func):
    """Register function as a safe tool."""
    TOOL_REGISTRY[func.__name__] = func
    return func

@tool
def get_current_balance(tbl):
    return inv_utils.get_current_balance(tbl)

@tool
def next_transaction_id(tbl, prefix="TXN"):
    return inv_utils.next_transaction_id(tbl, prefix)

# Now auto-populate SAFE_GLOBALS
SAFE_GLOBALS = {"Query": Query, **TOOL_REGISTRY}
```

Benefits:
- Add new tools by decorating them—no manual dict updates
- Self-documenting: grep for `@tool` to see what's available
- Can add metadata (docstrings, schemas) for LLM prompts

## 2. **RestrictedPython (Sandboxed Execution)**

Use the [`RestrictedPython`](https://pypi.org/project/RestrictedPython/) library to compile code with safety guards built-in:

```python
from RestrictedPython import compile_restricted, safe_globals

# Compile with restrictions
byte_code = compile_restricted(code, '<string>', 'exec')

# Execute with safe builtins
restricted_globals = {
    **safe_globals,
    "Query": Query,
    "db": db,
    # ... your tools
}
exec(byte_code, restricted_globals)
```

Benefits:
- Automatically blocks dangerous operations (file I/O, imports, etc.)
- No manual namespace management
- Production-ready (used by Zope, Plone)

## 3. **Code Interpreter Pattern (Structured Plans)**

Instead of executing arbitrary Python, have the LLM generate **structured plans** (JSON) that reference pre-approved tools:

```python
# LLM generates this
plan = {
    "steps": [
        {"tool": "get_inventory_data", "args": {"product_name": "Aviator"}},
        {"tool": "update_inventory", "args": {"item_id": "SG001", "delta": -2}}
    ]
}

# Executor just dispatches to registry
for step in plan["steps"]:
    tool_func = TOOL_REGISTRY[step["tool"]]
    result = tool_func(**step["args"])
```

Benefits:
- **Zero arbitrary code execution**—only pre-vetted tools run
- Easy to audit, log, and replay
- This is what `M5_UGL_1.ipynb` does (the multi-agent version)

## 4. **Isolated Subprocess Execution**

Run generated code in a separate process with resource limits:

```python
import subprocess
import tempfile

def execute_in_sandbox(code: str, timeout: int = 5) -> dict:
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(code)
        script_path = f.name
    
    try:
        result = subprocess.run(
            ['python', script_path],
            capture_output=True,
            timeout=timeout,
            text=True
        )
        return {"stdout": result.stdout, "stderr": result.stderr}
    except subprocess.TimeoutExpired:
        return {"error": "Execution timeout"}
    finally:
        os.unlink(script_path)
```

Benefits:
- Complete isolation from main process
- Can use Docker/containers for even stronger sandboxing
- Resource limits (CPU, memory, network) via OS-level controls

## 5. **LangChain/LlamaIndex Tool Abstractions**

Use framework-provided tool systems that handle registration automatically:

```python
from langchain.tools import tool

@tool
def get_inventory_data(product_name: str) -> dict:
    """Lookup product in inventory."""
    return inventory_tbl.search(Query().name == product_name)

# Framework handles execution, validation, error handling
agent = create_agent(tools=[get_inventory_data, ...])
```

Benefits:
- Built-in safety, logging, retries
- No manual namespace management
- Integrates with LLM frameworks

## **Recommendation for Your Use Case**

Given you want less boilerplate while maintaining safety:

**Short term (demo/prototype):**
- Use **decorator-based tool registry** (#1) to eliminate manual `SAFE_GLOBALS` updates

**Medium term (production):**
- Switch to **structured plans** (#3) like `M5_UGL_1.ipynb` does—no arbitrary code execution, just tool dispatch

**Long term (enterprise):**
- Combine **RestrictedPython** (#2) or **subprocess sandboxing** (#4) with tool registries for defense-in-depth

The key insight: **don't execute arbitrary Python in production**. Instead, have the LLM generate structured instructions (JSON plans) that reference a curated tool library. This gives you:
- ✅ No manual namespace tracking
- ✅ Auditable execution
- ✅ Easy to extend (just add decorated tools)
- ✅ Safe by design (no `exec` of untrusted code)

---

Exactly. TinyDB provides a lightweight query API that covers common filtering needs without SQL:

## Built-in Query Operations

```python
from tinydb import Query

q = Query()

# 1. Equality
inventory_tbl.search(q.name == "Aviator")

# 2. Comparison operators
inventory_tbl.search(q.price > 100)
inventory_tbl.search(q.quantity_in_stock >= 5)

# 3. Logical operators
inventory_tbl.search((q.price < 100) & (q.quantity_in_stock > 0))
inventory_tbl.search((q.name == "Aviator") | (q.name == "Wayfarer"))
inventory_tbl.search(~(q.price > 200))  # NOT

# 4. String matching
inventory_tbl.search(q.name.matches(r'.*aviator.*', flags=re.IGNORECASE))

# 5. Existence checks
inventory_tbl.search(q.description.exists())

# 6. Custom tests (for complex logic)
inventory_tbl.search(q.name.test(lambda n: "round" in n.lower()))
```

## What TinyDB **Doesn't** Support

- ❌ Joins across tables
- ❌ Aggregations (SUM, AVG, GROUP BY)
- ❌ Indexes (everything is scanned)
- ❌ Transactions/ACID guarantees
- ❌ SQL syntax

So yes, TinyDB has "query utilities," but they're intentionally minimal—enough for filtering documents in small datasets, but not a replacement for relational databases when you need complex queries, performance at scale, or data integrity guarantees.

For this lab's sunglasses store demo (dozens of records), TinyDB's query API is perfectly adequate. For production with thousands of SKUs and concurrent transactions, you'd migrate to SQLite/PostgreSQL/DuckDB.

---

Great. Can you now help me refactor the notebook multiagent/M5_lab1/M5_UGL_1_R.ipynb into resuable modules under multiagent/customer_service, and use customer_service_agent() in the noteook as a template to create a driver script that demonstrates the single-agent workflow? 

Note that, next, we also want to refactor the other notebook multiagent/M5_lab1/M5_UGL_1.ipynb, demonstrating the multi-agent workflow. 

Which agent will work better? 

---

I’ll refactor the single‑agent notebook into a small `multiagent/customer_service` package and add a driver script that mirrors `customer_service_agent()` but runs outside the notebook. Then I’ll briefly compare when the single‑agent vs multi‑agent designs are preferable.

First I’ll scan the lab folder to see all the supporting modules (`inv_utils`, `utils`, etc.) and then create the new package and script.

## Plan

I’ll break this into two parts:

1. How to refactor `M5_UGL_1_R.ipynb` into a reusable **single‑agent** package + driver script.
2. How that compares to the **multi‑agent** notebook and when each is a better choice.

If you like the structure, I can then actually create the modules and script.

---

## 1. Refactoring the single‑agent notebook into `multiagent/customer_service/`

From the notebook, the key reusable pieces are:

- Data / TinyDB layer: `inv_utils.seed_db`, `create_inventory`, `create_transactions`, `build_schema_block`, `get_current_balance`, `next_transaction_id`.
- LLM planning: `PROMPT` and `generate_llm_code(...)`.
- Code execution sandbox: `_extract_execute_block(...)` and `execute_generated_code(...)`.
- Orchestration: `customer_service_agent(...)`.

A clean package layout:

```text
multiagent/
  customer_service/
    __init__.py
    data.py          # TinyDB seeding + schema
    planning.py      # PROMPT + generate_llm_code
    execution.py     # _extract_execute_block + execute_generated_code
    single_agent.py  # customer_service_agent (notebook‑free version)
    cli_single.py    # (optional) CLI / driver script
```

### `data.py` (TinyDB adapter)

Wrap the existing `inv_utils` so notebook and scripts both use the same entrypoints:

- `seed_db()` → returns `(db, inventory_tbl, transactions_tbl)`
- `reset_demo_data()` → reseeds inventory & transactions
- `build_schema_block(inventory_tbl, transactions_tbl)` → as in notebook

This can just import `inv_utils` and forward calls so you don’t duplicate logic.

### `planning.py`

Move the big `PROMPT` and `generate_llm_code`:

```python
def generate_llm_code(
    prompt: str,
    *,
    inventory_tbl,
    transactions_tbl,
    model: str = "o4-mini",
    temperature: float = 0.2,
    client: Optional[OpenAI] = None,
) -> str:
    ...
```

Changes vs notebook:

- Accept an optional `client` object (so scripts/tests can inject a client).
- Remove [utils.print_html](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/utils.py:24:0-103:29) calls – pure logic.

### `execution.py`

Move the executor and keep it notebook‑agnostic:

```python
def extract_execute_block(text: str) -> str: ...

def execute_generated_code(
    code_or_content: str,
    *,
    db,
    inventory_tbl,
    transactions_tbl,
    user_request: Optional[str] = None,
) -> dict[str, Any]:
    """
    Returns: { code, stdout, error, answer, inventory_tbl, transactions_tbl }
    """
```

Changes vs notebook:

- No [print_html](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/utils.py:24:0-103:29); just return plain data.
- Keep the same SAFE_GLOBALS/SAFE_LOCALS behavior (for now) but in a separate module.

Later, if you decide to move to a tool‑based executor, you only change `execution.py`.

### `single_agent.py`

Refactor `customer_service_agent` into a reusable entrypoint:

```python
from .data import seed_db, reset_demo_data
from .planning import generate_llm_code
from .execution import execute_generated_code

def customer_service_agent(
    question: str,
    *,
    model: str = "o4-mini",
    temperature: float = 1.0,
    reseed: bool = False,
    client: Optional[OpenAI] = None,
) -> dict[str, Any]:
    """
    Runs: reseed (optional) → generate plan-as-code → execute plan.
    Returns dict with: question, full_content, exec, and maybe snapshot tables.
    """
```

Key differences from the notebook version:

- It owns the DB lifecycle: calls `seed_db()` internally instead of assuming `db`, `inventory_tbl`, `transactions_tbl` exist globally.
- It returns pure data:

```python
{
  "question": question,
  "full_content": "<execute_python>...</execute_python>",
  "exec": {
      "code": ...,
      "stdout": ...,
      "error": ...,
      "answer": ...,
      "inventory_after": [...],
      "transactions_after": [...],
  },
}
```

- Any UI is left to the caller (notebook or CLI).

### `cli_single.py` – driver script

A simple script that demonstrates the single‑agent flow outside Jupyter:

```python
#!/usr/bin/env python3

from dotenv import load_dotenv
from openai import OpenAI
from multiagent.customer_service.single_agent import customer_service_agent

def main():
    load_dotenv()
    client = OpenAI()

    question = "I want to buy 3 pairs of classic sunglasses and 1 pair of aviator sunglasses."
    result = customer_service_agent(
        question,
        model="o4-mini",
        temperature=1.0,
        reseed=True,
        client=client,
    )

    print("USER:", result["question"])
    print("\nANSWER:", result["exec"]["answer"])
    print("\nSTDOUT LOGS:\n", result["exec"]["stdout"])
    if result["exec"]["error"]:
        print("\nERROR:\n", result["exec"]["error"])

if __name__ == "__main__":
    main()
```

In the notebook, you’d replace the inline implementation with:

```python
from multiagent.customer_service.single_agent import customer_service_agent
from multiagent.customer_service.data import seed_db

db, inventory_tbl, transactions_tbl = seed_db()
out = customer_service_agent(
    prompt,
    model="o4-mini",
    reseed=False,   # you already seeded
)
```

Or keep using the notebook’s `db`/tables if you prefer, but the logic lives in the package.

If you’re happy with this structure, I can create these modules and the script in the next step.

---

## 2. Refactoring the multi‑agent notebook later

For `multiagent/M5_lab1/M5_UGL_1.ipynb` (the tools‑only, multi‑agent pipeline), we can mirror the design:

```text
multiagent/
  customer_service/
    multi_agent/
      __init__.py
      tools.py            # reused from current lab
      executor.py         # execute_plan_tools_only, etc.
      planner.py          # generate_plan (TOOLS_ONLY spec)
      reflector.py        # reflect_on_plan
      explainer.py        # explain_execution_error
      workflow.py         # end-to-end run(user_prompt)
```

Then you’d have:

- `single_agent.customer_service_agent(...)` (code‑as‑plan)
- `multi_agent.run_workflow(...)` (tools‑based plan + reflection)

Both can be demoed from notebooks or scripts.

---

## 3. Which agent “works better”?

They’re optimized for different things:

### Single‑agent (code‑as‑plan; `M5_UGL_1_R`)

**Pros:**

- Very **expressive**: the LLM can use Python/TinyDB as a rich language (loops, conditionals, custom logic).
- Great for **experimentation** and teaching “code as action”.
- Fewer moving parts: one prompt, one executor.

**Cons:**

- Harder to **control and audit**: arbitrary Python via `exec`, even with SAFE_GLOBALS.
- Safety & governance are more complex (you must sandbox properly).
- Harder to test individual behaviors (logic is buried in generated code blobs).

**Best for:**

- Educational labs (like this one).
- Quick prototypes where you trust the environment and need flexibility.

### Multi‑agent, tools‑only (`M5_UGL_1`)

**Pros:**

- **Structured** and auditable: plans are JSON with explicit tool calls.
- Clear **separation of concerns**:
  - Planner → constructs plan
  - Reflector → corrects/normalizes plan
  - Executor → runs tools and validations
  - Explainer → user‑facing error messages
- Easier to add safety constraints (e.g., *no raw SQL, only these tools*).
- Much better fit for **production**: logging, debugging, unit testing are straightforward.

**Cons:**

- Less raw expressiveness than arbitrary Python; complex logic may need new tools.
- More moving parts and prompts to maintain.

**Best for:**

- Production workflows you want to deploy and maintain.
- Systems requiring **policy enforcement**, **observability**, and **reliability**.
- Cases where multiple roles (planner, reviewer, executor) add value.

### Recommendation

- For this course’s **single‑agent** story and to showcase “planning with code execution”, keep and refactor the `M5_UGL_1_R` style into `multiagent.customer_service.single_agent`.
- For anything you might actually run in a **real system**, the **multi‑agent tools‑only** design is the one to invest in and harden.

If you confirm you like the package layout above, I’ll:

1. Create `multiagent/customer_service/` with `data.py`, `planning.py`, `execution.py`, `single_agent.py`.
2. Add a `cli_single.py` driver.
3. Adjust the notebook to import and use `customer_service_agent()` instead of the inline definitions.

---

Let's not touch the notebook but I like your design. The refactored code doesn't need to strickly follow the notebook's logic if better design exists. 

I agree that "For this course’s single‑agent story and to showcase “planning with code execution”, keep and refactor the M5_UGL_1_R style into multiagent.customer_service.single_agent."

Ultimately, we want to implement and enhance the multiagent workflow as the package suggests. 

I like the package design. 
Do you think we'll be able to enhance or generalize data.py to handle SQLite as well? Or even MySQL? 

data.py might sound a bit generic, how about data_access.py? 

single_agent.py is good because we'll likely experiment on other modalities such as multiagent workflows

---

### Short answer

- Yes, we can absolutely generalize `data.py` into a backend‑agnostic `data_access.py`.
- We’d define a **common interface** (TinyDB, SQLite, MySQL) and then plug in concrete implementations.
- Naming it `data_access.py` is better; it suggests a data‑access layer rather than a specific store.

Below is how I’d shape it, without touching the notebook.

---

## 1. Package layout with data access layer

Given your preferences, I’d aim for:

```text
multiagent/
  customer_service/
    __init__.py
    data_access.py        # backing store abstraction
    planning.py           # prompt + generate_llm_code
    execution.py          # execute_generated_code
    single_agent.py       # customer_service_agent (single-agent, code-as-plan)
    # later:
    # multi_agent/
    #   ...
```

The notebook keeps its existing imports; the new code is for scripts/libraries.

---

## 2. `data_access.py`: interface + TinyDB implementation

Define a **minimal interface** that covers everything the agent needs, regardless of backend:

```python
from abc import ABC, abstractmethod
from typing import Any, Iterable

class CustomerServiceStore(ABC):
    @abstractmethod
    def seed_demo_data(self) -> None: ...
    @abstractmethod
    def get_inventory(self) -> list[dict]: ...
    @abstractmethod
    def get_transactions(self) -> list[dict]: ...
    @abstractmethod
    def get_current_balance(self) -> float: ...
    @abstractmethod
    def next_transaction_id(self, prefix: str = "TXN") -> str: ...
    @abstractmethod
    def update_inventory_quantity(self, item_id: str, new_qty: int) -> None: ...
    @abstractmethod
    def insert_transaction(self, row: dict[str, Any]) -> None: ...
```

Then a TinyDB implementation that basically wraps `inv_utils`:

```python
class TinyDBStore(CustomerServiceStore):
    def __init__(self, path: str = "store_db.json"):
        self.db, self.inventory_tbl, self.transactions_tbl = inv_utils.seed_db(path)

    def seed_demo_data(self) -> None:
        inv_utils.create_inventory()
        inv_utils.create_transactions()

    def get_inventory(self) -> list[dict]:
        return self.inventory_tbl.all()

    def get_transactions(self) -> list[dict]:
        return self.transactions_tbl.all()

    def get_current_balance(self) -> float:
        return inv_utils.get_current_balance(self.transactions_tbl)

    def next_transaction_id(self, prefix: str = "TXN") -> str:
        return inv_utils.next_transaction_id(self.transactions_tbl, prefix)

    def update_inventory_quantity(self, item_id: str, new_qty: int) -> None:
        self.inventory_tbl.update({"quantity_in_stock": new_qty}, Query().item_id == item_id)

    def insert_transaction(self, row: dict[str, Any]) -> None:
        self.transactions_tbl.insert(row)
```

Your **single‑agent** code can depend only on `CustomerServiceStore`, not TinyDB specifics.

---

## 3. SQLite and MySQL later

Because the interface is small, adding relational backends becomes straightforward:

```python
class SQLiteStore(CustomerServiceStore):
    def __init__(self, conn_str: str = "sqlite:///customer_service.db"):
        # use sqlite3 or SQLAlchemy here
        ...

class MySQLStore(CustomerServiceStore):
    def __init__(self, conn_str: str):
        # use SQLAlchemy or mysqlclient
        ...
```

Each implementation just:

- Stores inventory in a table `inventory` (item_id, name, description, quantity_in_stock, price).
- Stores transactions in `transactions` (transaction_id, customer_name, transaction_summary, amount, balance_after_transaction, timestamp).
- Implements the same methods: `get_current_balance`, `next_transaction_id`, etc.

The agent doesn’t change; you just swap the store:

```python
from multiagent.customer_service.data_access import TinyDBStore, SQLiteStore
from multiagent.customer_service.single_agent import customer_service_agent

store = TinyDBStore()       # or SQLiteStore(), MySQLStore()
result = customer_service_agent(
    question="Return 2 Aviator sunglasses",
    store=store,
    model="o4-mini",
)
```

So **yes**, the design naturally extends to SQLite/MySQL by:

- Keeping `data_access.py` as the abstraction boundary.
- Implementing backends behind a small, stable interface.

---

## 4. Single‑agent module signature

With this in mind, `single_agent.py` would take a store instead of raw TinyDB objects:

```python
def customer_service_agent(
    question: str,
    *,
    store: CustomerServiceStore,
    model: str = "o4-mini",
    temperature: float = 1.0,
    reseed: bool = False,
    client: Optional[OpenAI] = None,
) -> dict[str, Any]:
    ...
```

Internally it uses `store.get_inventory()`, `store.update_inventory_quantity(...)`, etc., and the execution layer keeps using the same pattern (code‑as‑plan).

---

If you’re happy with `data_access.py` as the abstraction point and the `CustomerServiceStore` interface, I can go ahead and implement:

- `multiagent/customer_service/data_access.py` with `CustomerServiceStore` and `TinyDBStore`.
- `multiagent/customer_service/planning.py`, `execution.py`, `single_agent.py` wired to the TinyDB store.



---

@data_access.py#L18 

Let's not make this package (customer_service) dependent on M5, which is meant for educational purposes and is meant to be a standalone unit. 

You could simply copy and paste these dependent module here in this package but refactor them into a better resuable design. 

---

