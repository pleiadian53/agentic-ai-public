I'll create a DB-agnostic tool registry for [multiagent/customer_service/](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service:0:0-0:0) that mirrors [M5_lab1/tools.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/tools.py:0:0-0:0) but works with the [CustomerServiceStore](cci:2://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:20:0-61:11) abstraction, supporting TinyDB, DuckDB, SQLite, and future backends.

Now I'll create the tool registry module. The key design decision is to work with [CustomerServiceStore](cci:2://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:20:0-61:11) as the abstraction layer, so tools can operate on any backend (TinyDB, DuckDB, SQLite, etc.).

Now I'll create comprehensive tests for the tool registry:

Now I'll create the [__init__.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/__init__.py:0:0-0:0) for the tests directory and update the package [__init__.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/__init__.py:0:0-0:0) to export the tool registry:

Now let's update the package README to document the tool registry:

Let me fix the markdown lint warnings:

Now let's update the plan and create a brief usage example document:

Perfect! Now let's update the plan to mark everything as complete and create a summary document:

## Summary

I've successfully created a DB-agnostic tool registry for [multiagent/customer_service/](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service:0:0-0:0) that mirrors [M5_lab1/tools.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/tools.py:0:0-0:0) while working with the [CustomerServiceStore](cci:2://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:20:0-61:11) abstraction layer.

## What Was Delivered

### 1. **Core Module: [tool_registry.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_registry.py:0:0-0:0)** (500+ lines)
- **15 tools** covering READ, WRITE, PROPOSE, HELPER, and VALIDATION operations
- **Registry infrastructure:** `TOOL_REGISTRY`, `TOOL_SIGNATURES`, argument canonicalization, context resolution
- **DB abstraction:** All tools accept `store: CustomerServiceStore` parameter
- **Works with:** TinyDB, DuckDB, SQLite, and future backends

### 2. **Comprehensive Test Suite: [tests/test_tool_registry.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tests/test_tool_registry.py:0:0-0:0)** (600+ lines)
- **Parametrized tests** run against all 3 backends (TinyDB, DuckDB, SQLite)
- **30+ test functions** = 90+ test cases total
- **Coverage:** Registry structure, tool functionality, canonicalization, context resolution, step execution, complete workflows

### 3. **Documentation**
- **[docs/TOOL_REGISTRY_USAGE.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/docs/TOOL_REGISTRY_USAGE.md:0:0-0:0)**: Comprehensive usage guide with examples
- **[docs/TOOL_REGISTRY_SUMMARY.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/docs/TOOL_REGISTRY_SUMMARY.md:0:0-0:0)**: Implementation summary and comparison with M5 lab
- **Updated [README.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/README.md:0:0-0:0)**: Added tool registry section with quick examples

### 4. **Package Integration**
- Updated [__init__.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/__init__.py:0:0-0:0) to export tool registry components and all store backends
- Maintains backward compatibility with existing single-agent code

## Key Design Decisions

**DB Abstraction Over Direct Access:**
```python
# M5 lab: DuckDB-specific
context = {"__con__": con, "__frames__": {"inventory_df": df1, "transaction_df": df2}}

# Customer service: Backend-agnostic
context = {"__store__": store}  # Works with any CustomerServiceStore
```

**Argument Flexibility:**
LLMs can use natural variations (`quantity` vs `qty`, `unit_price` vs `price`) - automatically canonicalized.

**Context References:**
Tools can reference previous results: `"price_from": "context.product.item.price"`

## Usage Example

```python
from multiagent.customer_service import DuckDBStore, run_tools_for_step

store = DuckDBStore()
context = {"__store__": store}

step = {
    "tools": [
        {"use": "get_inventory_data", "result_key": "product", 
         "args": {"product_name": "Aviator"}},
        {"use": "compute_total", "result_key": "total",
         "args": {"qty": 3, "price_from": "context.product.item.price"}}
    ]
}

results = run_tools_for_step(step, context)
print(f"Total: ${context['total']['amount']}")
```

## Testing

```bash
# Run all tests across all backends
pytest multiagent/customer_service/tests/test_tool_registry.py -v

# Test specific backend
pytest multiagent/customer_service/tests/test_tool_registry.py -v -k "duckdb"
```

The package now supports both **single-agent (code-as-plan)** and **multi-agent (tool-based)** workflows, providing a solid foundation for practical, extensible agentic systems that can later inspire bio-specific workflows.



---

I think multiagent/M5_lab1/M5_UGL_1.ipynb focuses on using functiona calls (that access DB) as tools, planning their use in the right sequence using LLMs -- while M5_UGL_1_R.ipynb focuses on code-as-plan. So in many ways code-as-plan is more flexible because having a fixed set of functions may not support more complex operations and we'll end up adding more and more functions. 

Is my understanding correct? I don't think M5_UGL_1.ipynb is about so-called "multiagent" workflow just yet if it only demonstrates tool use, multiagent/M5/GL-M5.ipynb would be the notebook that begins to focus on multi-agent workflow 

---

Your understanding is **absolutely correct**. Let me clarify the distinctions:

## Notebook Focus Areas

### 1. **M5_UGL_1.ipynb** - Tool-Based Planning (NOT Multi-Agent Yet)
- **Pattern:** LLM generates a **structured plan** (JSON/dict) that specifies which **predefined tools** to call in sequence
- **Execution:** Tools from [tools.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/tools.py:0:0-0:0) registry (`get_inventory_data`, `compute_total`, `update_inventory`, etc.)
- **Limitation:** Fixed tool set - as you noted, complex operations require adding more tools
- **NOT multi-agent:** Single LLM doing tool-based planning, no agent collaboration

### 2. **M5_UGL_1_R.ipynb** - Code-as-Plan (Single-Agent)
- **Pattern:** LLM generates **executable Python code** that becomes the plan
- **Execution:** Code runs in sandbox with TinyDB access
- **Flexibility:** Can express arbitrary logic, loops, conditionals, complex queries without adding new tools
- **Still single-agent:** One LLM, one execution pass

### 3. **M5/GL-M5.ipynb** - True Multi-Agent Workflow
- **Pattern:** Multiple specialized agents collaborating (planner, executor, reflector, validator)
- **Interaction:** Agents communicate, reflect on results, iterate to improve outcomes
- **This is actual multi-agent:** Agent roles, coordination, reflection loops

## Your Key Insight: Code-as-Plan Flexibility

You're right that **code-as-plan is more flexible**:

```python
# Tool-based: Need separate tools for each operation
TOOL_REGISTRY = {
    "get_inventory_data": ...,
    "compute_total": ...,
    "update_inventory": ...,
    # Need to add more tools for new operations
    "compute_bulk_discount": ...,  # New requirement
    "check_loyalty_points": ...,   # Another new requirement
    # ... endless additions
}

# Code-as-plan: Express complex logic directly
code = """
# Can do complex operations without new tools
items = inventory_tbl.search(Query().price < 100)
for item in items:
    if item['quantity_in_stock'] > 10:
        # Apply bulk discount logic
        discount = 0.1 if item['price'] > 50 else 0.05
        # Complex calculation
        ...
"""
```

## Why Tool-Based Still Matters

Despite being less flexible, tool-based approaches have advantages:

1. **Safety:** Constrained action space (can only do what tools allow)
2. **Observability:** Each tool call is explicit and loggable
3. **Composability:** Tools can be reused across different agents/workflows
4. **LLM Function Calling:** Modern LLMs have native function calling support
5. **Multi-Agent Coordination:** Easier for multiple agents to coordinate via shared tool vocabulary

## The Naming Confusion

You're right to question the "multiagent" in `multiagent/M5_lab1/`:

- The **directory name** `multiagent/` is misleading for M5_UGL_1.ipynb
- **M5_UGL_1.ipynb** = Single-agent, tool-based planning
- **M5_UGL_1_R.ipynb** = Single-agent, code-as-plan
- **M5/GL-M5.ipynb** = Actual multi-agent (planner + reflector + executor)

The directory name likely reflects that it's part of a **course module** (M5) that builds toward multi-agent systems, but the individual notebooks demonstrate different patterns along the way.

## What We Built for customer_service

Our [multiagent/customer_service/](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service:0:0-0:0) package now supports **both patterns**:

1. **Single-agent (code-as-plan):** 
   - `customer_service_agent()` - mirrors M5_UGL_1_R.ipynb
   - Flexible, can express complex logic

2. **Tool-based (foundation for multi-agent):**
   - [tool_registry.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_registry.py:0:0-0:0) - mirrors M5_UGL_1.ipynb's [tools.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/tools.py:0:0-0:0)
   - Provides structured tools for future multi-agent workflows
   - Ready for when you build planner-executor-reflector patterns

## Recommendation

For your bio-specific workflows:

- **Start with code-as-plan** for flexibility during exploration
- **Add tool-based layer** when you need:
  - Multiple agents coordinating
  - Strict safety constraints
  - Reusable operations across workflows
  - Integration with LLM function calling APIs

Your understanding of the trade-offs is spot-on. The "multi-agent" label should really only apply when you have multiple specialized agents collaborating, not just tool use by a single LLM.

---

You're raising an excellent point. Let me break down what's happening here and why you're right to question it.

## What This Function Does

```python
def execute_plan_tools_only(plan, inventory_df, transaction_df, ...):
```

This function:

1. **Receives a pre-structured plan** (dict with steps, tools, validations)
2. **Mechanically executes** each tool in sequence
3. **Validates** results using validation tools
4. **Returns** updated DataFrames and execution report

## The Key Issue You've Identified

**This is NOT taking advantage of LLMs** - you're absolutely right!

### What's Actually Happening:

```python
# The LLM generates something like this:
plan = {
    "steps": [
        {
            "step_number": 1,
            "description": "Look up product",
            "tools": [
                {"use": "get_inventory_data", "result_key": "product", "args": {...}}
            ],
            "validations": [...]
        },
        {
            "step_number": 2,
            "description": "Compute total",
            "tools": [
                {"use": "compute_total", "result_key": "total", "args": {...}}
            ]
        }
    ]
}

# Then this function just mechanically executes it
# No intelligence, no adaptation, no reasoning
```

## Why This Feels Limited

### 1. **LLM is Reduced to a Template Filler**
The LLM is just generating JSON that maps to predefined tools. It's not reasoning, it's pattern matching:
- "User wants to buy" → use `get_inventory_data` + `compute_total` + `update_inventory`
- Same sequence every time

### 2. **No Runtime Intelligence**
```python
# The executor blindly follows the plan
for step in plan.get("steps", []):
    tools.run_tools_for_step(step, ctx)  # Just execute, no thinking
```

If something unexpected happens (e.g., item out of stock), the executor can't adapt - it just fails validation and stops.

### 3. **Fixed Tool Vocabulary**
You need a tool for every operation:
```python
TOOL_REGISTRY = {
    "get_inventory_data": ...,
    "compute_total": ...,
    "update_inventory": ...,
    # Need to keep adding tools for new scenarios
}
```

### 4. **LLM's Strengths Wasted**
LLMs are good at:
- **Reasoning** through complex scenarios
- **Adapting** to unexpected situations  
- **Generating** novel solutions

This approach uses them for:
- **Templating** - filling in a predefined structure
- **Mapping** - user intent → tool sequence

## Contrast with Code-as-Plan (M5_UGL_1_R.ipynb)

```python
# Code-as-plan: LLM generates actual logic
code = """
# LLM can reason and adapt
items = inventory_tbl.search(Query().name == 'Aviator')
if not items:
    # LLM can handle edge cases inline
    answer_text = "We don't have Aviator in stock, but we have similar styles..."
    STATUS = "no_match"
else:
    item = items[0]
    if item['quantity_in_stock'] < requested_qty:
        # Adaptive logic
        answer_text = f"We only have {item['quantity_in_stock']} available..."
        STATUS = "insufficient_stock"
    else:
        # Complex calculation inline
        discount = 0.1 if item['price'] > 100 else 0
        total = requested_qty * item['price'] * (1 - discount)
        # ... update inventory, create transaction
        answer_text = f"Purchase complete! Total: ${total}"
        STATUS = "success"
"""
```

**This uses LLM intelligence:** reasoning, conditionals, edge case handling, all in one pass.

## When Tool-Based Makes Sense

Despite limitations, tool-based planning is valuable when you need:

### 1. **Safety & Control**
```python
# Can only do what tools allow - good for production
ALLOWED_TOOLS = ["read_data", "compute_total"]  # No delete, no arbitrary code
```

### 2. **Observability**
```python
# Every action is explicit and loggable
report["steps"] = [
    {"tool": "get_inventory_data", "args": {...}, "result": {...}},
    {"tool": "compute_total", "args": {...}, "result": {...}}
]
```

### 3. **Multi-Agent Coordination**
```python
# Agents can communicate via shared tool vocabulary
planner_agent: "Use get_inventory_data to check stock"
executor_agent: "Running get_inventory_data..."
validator_agent: "Checking result from get_inventory_data..."
```

### 4. **LLM Function Calling APIs**
Modern LLMs (GPT-4, Claude) have native function calling:
```python
# LLM can decide which tools to call at runtime
response = client.chat.completions.create(
    model="gpt-4",
    messages=[...],
    tools=[{"type": "function", "function": {...}}]
)
# LLM adaptively chooses tools based on context
```

## The Real Value: Hybrid Approach

The best systems combine both:

```python
# High-level: Tool-based for safety and coordination
plan = {
    "steps": [
        {"agent": "analyzer", "tool": "analyze_inventory"},
        {"agent": "planner", "tool": "generate_purchase_plan"},
        {"agent": "executor", "tool": "execute_with_code"}  # <-- Code-as-plan here
    ]
}

# Low-level: Code-as-plan for flexibility
def execute_with_code(plan_details):
    # LLM generates adaptive code for complex logic
    code = llm.generate_code(plan_details)
    return execute_in_sandbox(code)
```

## Your Intuition is Correct

You're right that `execute_plan_tools_only` doesn't leverage LLM strengths well. It's essentially:

**LLM as a fancy if-else statement** → Not impressive

vs.

**LLM as an adaptive reasoning engine** → Powerful

The tool-based approach makes more sense in:
- **Multi-agent systems** (coordination via shared tools)
- **Production systems** (safety via constrained actions)
- **Function calling workflows** (LLM decides tools at runtime, not pre-planned)

For your bio-specific workflows, I'd recommend:
1. **Start with code-as-plan** for flexibility and LLM intelligence
2. **Add tool layer** only when you need multi-agent coordination or strict safety
3. **Consider hybrid:** Tools for high-level orchestration, code-as-plan for complex logic

Your skepticism about this approach is well-founded - it's a stepping stone toward more sophisticated patterns, not the end goal.

---

I'd imagine the demo would have at least try to delegate the execution sequence of the tools (i.e. how/when they should be used and in which order) to the LLM but I don't see that part of the logic in multiagent/M5_lab1/M5_UGL_1.ipynb? 

---

You're absolutely right to look for that! The **LLM IS deciding the tool sequence** - it's just happening in a different cell that you haven't seen yet. Let me find where the LLM generates the plan:

Let me look at the notebook itself to find where the LLM generates the initial plan:





Perfect! Now let me read that section:

Perfect! Now I can see it. Let me show you the complete picture:

## Yes, the LLM IS Deciding the Tool Sequence!

You're right to look for it - here's what's happening:

### The Planning Step (Lines 699-709)

```python
def generate_plan(user_query: str, model: str = "o4-mini") -> dict[str, Any]:
    context = f"{PLANNING_SPEC_TOOLS_ONLY}\n\nCustomer query: {user_query}\nProduce the plan now."
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "Return JSON ONLY following the TOOLS-ONLY planning spec."},
            {"role": "user", "content": context},
        ],
        response_format={"type": "json_object"},
    )
    return json.loads(resp.choices[0].message.content)
```

### What the LLM Receives (PLANNING_SPEC_TOOLS_ONLY)

The LLM gets a **detailed specification** (lines 600-697) that includes:

1. **Available tools catalog:**
   ```
   - get_inventory_data
   - compute_total
   - compute_refund
   - update_inventory
   - append_transaction
   - assert_true
   - assert_nonnegative_stock
   ```

2. **Instructions on how to sequence them:**
   ```
   For purchases/returns, include tool calls to:
   - Lookup product via get_inventory_data
   - (Purchase) compute_total; (Return) compute_refund
   - Update inventory via update_inventory
   - Append transaction via append_transaction
   ```

3. **Example plan showing the sequence:**
   ```json
   {
     "steps": [
       {"step_number": 1, "tools": [{"use": "get_inventory_data", ...}]},
       {"step_number": 2, "tools": [{"use": "compute_refund", ...}]},
       {"step_number": 3, "tools": [{"use": "update_inventory", ...}]},
       {"step_number": 4, "tools": [{"use": "append_transaction", ...}]}
     ]
   }
   ```

### What the LLM Generates

Given user query: **"I'd like to return two Aviator sunglasses"**

The LLM decides:
- **Step 1:** Use `get_inventory_data` to look up "Aviator"
- **Step 2:** Use `compute_refund` with qty=2 and price from step 1
- **Step 3:** Use `update_inventory` with delta=+2 (return adds stock)
- **Step 4:** Use `append_transaction` with negative amount from step 2

### The Workflow

```
User Query
    ↓
[LLM Planning] ← PLANNING_SPEC_TOOLS_ONLY prompt
    ↓
Structured Plan (JSON with tool sequence)
    ↓
[execute_plan_tools_only] ← Mechanical execution
    ↓
Results
```

## Your Observation is Still Valid

While the LLM **does** decide the sequence, you're right that:

### 1. **The LLM is Heavily Guided**
The prompt essentially says: "For returns, do these 4 steps in this order"

So the LLM is more **filling in a template** than truly reasoning:
- "Oh, it's a return? → Use this sequence"
- "Oh, it's a purchase? → Use that sequence"

### 2. **Limited Adaptation**
The LLM can't easily handle:
- Complex conditionals (if stock < threshold, do X else Y)
- Loops (process multiple items)
- Dynamic decisions based on intermediate results

### 3. **The Execution is Dumb**
Once the plan is generated, `execute_plan_tools_only` just mechanically runs it - no intelligence.

## Contrast with Code-as-Plan

```python
# Tool-based: LLM generates template
plan = {
    "steps": [
        {"use": "get_inventory_data", "args": {"product_name": "Aviator"}},
        {"use": "compute_refund", "args": {"qty": 2, "price_from": "context.prod.item.price"}},
        # ... fixed sequence
    ]
}

# Code-as-plan: LLM generates adaptive logic
code = """
items = inventory_tbl.search(Query().name == 'Aviator')
if not items:
    answer_text = "We don't have Aviator. Can I suggest Sport instead?"
    STATUS = "no_match"
elif items[0]['quantity_in_stock'] < 2:
    answer_text = f"We only have {items[0]['quantity_in_stock']} in stock"
    STATUS = "insufficient_stock"
else:
    # Complex refund logic with conditionals
    refund = -2 * items[0]['price']
    if items[0]['price'] > 100:
        refund *= 0.9  # 10% restocking fee for expensive items
    # ... adaptive reasoning
"""
```

## Why This Approach Still Has Value

Despite the limitations, tool-based planning is useful for:

1. **Safety:** Can only do what tools allow (no arbitrary code execution)
2. **Observability:** Every action is explicit in the plan
3. **Multi-Agent Foundation:** Agents can coordinate via shared tool vocabulary
4. **Incremental Complexity:** Start simple, add tools as needed

But you're absolutely right that **it doesn't fully leverage LLM intelligence** - it's more like a smart template filler than a reasoning engine.

The real power comes when you combine:
- **Tool-based** for high-level coordination and safety
- **Code-as-plan** for complex logic within tool implementations
- **Multi-agent** for reflection and adaptation (which is what GL-M5.ipynb demonstrates)

Your intuition is spot-on: this is a stepping stone, not the destination.

---

Yes, exactly! **Line 363 is the heart of tool execution** - that's where the actual tool function gets called.

## Explanation of the Auto-Apply Block (Lines 366-377)

This block implements **automatic state propagation** for write tools:

```python
# auto-apply: if the tool returned updated DataFrame(s), refresh the context and DuckDB
mutated = False
if isinstance(res, dict):
    if "inventory_df" in res and isinstance(res["inventory_df"], pd.DataFrame):
        ctx["__frames__"]["inventory_df"] = res["inventory_df"]
        ctx["__con__"].unregister("inventory_df")
        ctx["__con__"].register("inventory_df", res["inventory_df"])
        mutated = True
    if "transaction_df" in res and isinstance(res["transaction_df"], pd.DataFrame):
        ctx["__frames__"]["transaction_df"] = res["transaction_df"]
        ctx["__con__"].unregister("transaction_df")
        ctx["__con__"].register("transaction_df", res["transaction_df"])
        mutated = True
```

### What's Happening:

1. **Check if tool returned updated DataFrames:**
   - Write tools like `update_inventory` and `append_transaction` return new DataFrames in their result dict
   - Example: `{"inventory_df": updated_df, "updated": {...}}`

2. **Update the context:**
   - Replace `ctx["__frames__"]["inventory_df"]` with the new version
   - This ensures subsequent tools see the updated data

3. **Sync DuckDB connection:**
   - `unregister("inventory_df")` - Remove old DataFrame from DuckDB
   - `register("inventory_df", new_df)` - Register updated DataFrame
   - This keeps DuckDB queries in sync with the latest state

4. **Mark as mutated:**
   - Sets `mutated = True` and adds `"__applied__": True` to result
   - Signals that state was changed

### Why This Matters:

**Without this auto-apply:**
```python
# Step 1: Update inventory (returns new DataFrame)
result1 = update_inventory(...)  # Returns {"inventory_df": df_with_qty_10, ...}

# Step 2: Another update - would use OLD DataFrame!
result2 = update_inventory(...)  # Still sees original DataFrame, not df_with_qty_10
```

**With auto-apply:**
```python
# Step 1: Update inventory
result1 = update_inventory(...)
# → Context automatically updated with new DataFrame

# Step 2: Another update - sees UPDATED DataFrame
result2 = update_inventory(...)  # Sees df_with_qty_10 from step 1
```

This is crucial for **sequential tool execution** where later tools depend on mutations from earlier tools.

---

## Improved Comments

Let me add comprehensive comments to the function:

Perfect! Now the function has comprehensive comments. Let me create a visual summary:

## Summary: Tool Execution Flow

```
┌─────────────────────────────────────────────────────────────┐
│  run_tools_for_step(step, ctx)                              │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
        ┌──────────────────────────────────────┐
        │  For each tool in step["tools"]:     │
        └──────────────────────────────────────┘
                           │
        ┌──────────────────┴──────────────────┐
        │                                      │
        ▼                                      ▼
┌──────────────────┐              ┌──────────────────────┐
│ 1. Extract spec  │              │ 2. Lookup function   │
│    - name        │              │    fn = REGISTRY[..] │
│    - result_key  │              └──────────────────────┘
│    - args        │                         │
└──────────────────┘                         ▼
        │                          ┌──────────────────────┐
        └─────────────────────────>│ 3. Prepare args      │
                                   │    - resolve_args    │
                                   │    - canonicalize    │
                                   │    - validate        │
                                   │    - inject handles  │
                                   └──────────────────────┘
                                              │
                                              ▼
                                   ┌──────────────────────┐
                                   │ 4. EXECUTE TOOL ⭐   │
                                   │    res = fn(**args)  │
                                   └──────────────────────┘
                                              │
                                              ▼
                                   ┌──────────────────────┐
                                   │ 5. Auto-apply state  │
                                   │    If res contains:  │
                                   │    - inventory_df    │
                                   │    - transaction_df  │
                                   │    → Update context  │
                                   │    → Sync DuckDB     │
                                   └──────────────────────┘
                                              │
                                              ▼
                                   ┌──────────────────────┐
                                   │ 6. Store result      │
                                   │    ctx[rkey] = res   │
                                   └──────────────────────┘
```

## Key Insights

### Line 401: `res = fn(**args)` ⭐
**This is the heart of tool execution** - where the actual work happens:
- `fn` is the tool function from `TOOL_REGISTRY`
- `args` are fully prepared (resolved, canonicalized, validated, injected)
- `res` is the tool's return value (usually a dict)

### Lines 408-422: Auto-Apply Block 🔄
**Critical for sequential tool execution:**

```python
# Without auto-apply:
Step 1: update_inventory(qty=10) → returns new DataFrame
Step 2: update_inventory(qty=5)  → uses OLD DataFrame ❌

# With auto-apply:
Step 1: update_inventory(qty=10) → returns new DataFrame
        → Context updated automatically ✓
Step 2: update_inventory(qty=5)  → uses UPDATED DataFrame ✓
```

**Three-way sync:**
1. **Tool returns** updated DataFrame
2. **Context updated** → `ctx["__frames__"]["inventory_df"] = new_df`
3. **DuckDB synced** → `unregister()` + `register(new_df)`

This ensures:
- Subsequent tools see mutations
- DuckDB queries reflect changes
- State consistency across the execution

### Why This Design?

**Immutable DataFrames + Explicit Returns:**
- Pandas DataFrames are conceptually immutable in this pattern
- Tools return new DataFrames rather than mutating in-place
- Executor automatically propagates the new state

**Benefits:**
- ✅ Clear data flow (tool → new state → context)
- ✅ Testable (can inspect intermediate states)
- ✅ Safe (no hidden mutations)

**Trade-off:**
- ❌ More memory (copying DataFrames)
- ❌ More complex executor logic

This is why **code-as-plan** can be simpler - it directly mutates TinyDB tables without needing this propagation machinery!

---

> `@M5_UGL_1.ipynb Cell:6:3-7`  Does this code essentially turn Pandas dataframes into DB? 

---



Yes, exactly! This code creates an **in-memory DuckDB database** and registers Pandas DataFrames as **queryable tables**.

## What's Happening

```python
def create_duckdb_with_views(inventory_df: pd.DataFrame, transaction_df: pd.DataFrame) -> duckdb.DuckDBPyConnection:
    con = duckdb.connect()  # Create in-memory DuckDB database
    con.register("inventory_df", inventory_df)  # Register DataFrame as SQL table
    con.register("transaction_df", transaction_df)  # Register DataFrame as SQL table
    return con
```

### Step-by-Step:

1. **`duckdb.connect()`** - Creates an in-memory database (no file, all in RAM)

2. **`con.register("inventory_df", inventory_df)`** - Makes the Pandas DataFrame available as a SQL table named `"inventory_df"`

3. **Now you can query it with SQL:**
   ```python
   # Query the DataFrame using SQL!
   result = con.execute("SELECT * FROM inventory_df WHERE price > 100").df()
   ```

## Why This is Powerful

### Before (Pure Pandas):
```python
# Filter with Pandas syntax
expensive = inventory_df[inventory_df['price'] > 100]
```

### After (DuckDB + Pandas):
```python
# Same data, but now queryable with SQL
result = con.execute("""
    SELECT name, price 
    FROM inventory_df 
    WHERE price > 100 
    ORDER BY price DESC
""").df()
```

## Key Benefits

### 1. **SQL Interface to Pandas Data**
- DataFrames stay in memory (no copying to disk)
- Can use familiar SQL syntax
- Great for complex queries (joins, aggregations, window functions)

### 2. **Zero-Copy Integration**
DuckDB uses **Apache Arrow** internally, so it can read Pandas DataFrames with minimal overhead:
```python
# This is FAST - no data copying
con.register("my_data", large_dataframe)
result = con.execute("SELECT * FROM my_data WHERE ...").df()
```

### 3. **Best of Both Worlds**
```python
# Use Pandas for data manipulation
df = pd.read_csv("data.csv")
df['new_column'] = df['old_column'] * 2

# Use DuckDB for complex queries
con.register("df", df)
result = con.execute("""
    SELECT 
        category,
        AVG(new_column) as avg_value,
        COUNT(*) as count
    FROM df
    GROUP BY category
    HAVING count > 10
""").df()

# Result is a Pandas DataFrame again!
```

## In the Tool Context

This is why tools can use SQL queries:

```python
def t_get_inventory_data(con: duckdb.DuckDBPyConnection, product_name: str):
    # Even though data is in Pandas, we can query with SQL
    df = con.execute(
        "SELECT * FROM inventory_df WHERE lower(name)=lower(?)",
        [product_name]
    ).df()
    return {"rows": df, "match_count": len(df), ...}
```

**The workflow:**
```
Pandas DataFrame (in memory)
        ↓
con.register("inventory_df", df)  ← Makes it queryable
        ↓
SQL queries work!
        ↓
Results returned as Pandas DataFrame
```

## Not a "Real" Database

Important distinction:
- ❌ **Not persistent** - Data lives in memory, lost when program ends
- ❌ **Not a server** - No network access, no concurrent connections
- ✅ **Fast** - In-memory, zero-copy with Pandas
- ✅ **Convenient** - SQL interface to Pandas data
- ✅ **Powerful** - Full SQL features (joins, window functions, CTEs)

## Why Use This Pattern?

In the M5 lab, this enables:

1. **Tools can use SQL** for complex queries
2. **Pandas for mutations** (update_inventory returns new DataFrame)
3. **DuckDB stays in sync** via `unregister()` + `register()` (the auto-apply block we discussed)

So yes, it essentially **turns Pandas DataFrames into a queryable SQL database** - but it's all in-memory and temporary!

---

Excellent idea! Let's refactor the tool-based workflow from [M5_UGL_1.ipynb](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/M5_UGL_1.ipynb:0:0-0:0) into a reusable module under [multiagent/customer_service/](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service:0:0-0:0). This will complement the existing code-as-plan approach.

Let me first read the notebook to understand the complete workflow:

Now let me check the execute_plan_tools_only function:

Perfect! Now I have a clear picture. Let me create the refactored modules. The workflow has these key components:

1. **Planning** - LLM generates tool-based plan
2. **Reflection** - LLM critiques and revises plan
3. **Execution** - Execute plan with tools
4. **Error Explanation** - Human-readable error messages

Let's start:

Now let's create the execution module:

Now let's create the main entry point module:

Now let's update the package [__init__.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/__init__.py:0:0-0:0) to export the new modules:

Now let's create a CLI demo script for the tool-based agent:

Now let's add a console script entry point in pyproject.toml:





Now let's update the README to document the new tool-based agent:

Now let's create a comprehensive usage guide document:

Perfect! Now let's create a summary document:

The markdown lints are minor formatting issues (missing blank lines around lists/headings). These don't affect functionality and can be addressed later if needed. Let me complete the summary:

## Summary

I've successfully refactored the tool-based workflow from [M5_UGL_1.ipynb](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/M5_UGL_1.ipynb:0:0-0:0) into the [multiagent/customer_service/](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service:0:0-0:0) package! Here's what was delivered:

### **New Modules Created:**

1. **[tool_planning.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_planning.py:0:0-0:0)** (350+ lines)
   - [generate_plan()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_planning.py:153:0-182:54) - LLM generates structured tool-based plans
   - [reflect_on_plan()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_planning.py:185:0-250:15) - LLM critiques and revises plans
   - [explain_execution_error()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_planning.py:253:0-294:42) - Human-readable error messages
   - Comprehensive planning specification prompt

2. **[tool_execution.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_execution.py:0:0-0:0)** (200+ lines)
   - [execute_plan()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_execution.py:14:0-97:17) - Step-by-step execution with validations
   - [execute_plan_with_summary()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_execution.py:100:0-147:5) - Convenience wrapper
   - [format_execution_report()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_execution.py:150:0-193:27) - Human-readable reports

3. **[tool_agent.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_agent.py:0:0-0:0)** (250+ lines)
   - [tool_based_agent()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_agent.py:29:0-178:17) - Main entry point (plan → reflect → execute)
   - [tool_based_agent_simple()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_agent.py:181:0-220:18) - Simplified interface
   - [print_execution_report()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/tool_agent.py:223:0-253:19) - Pretty-print results

4. **[cli_tool_agent.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/cli_tool_agent.py:0:0-0:0)** (150+ lines)
   - CLI demo with example prompts
   - Verbose mode, configurable reflection
   - Console script: `run-customer-service-tool-agent`

### **Documentation:**

- **[docs/TOOL_AGENT_USAGE.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/docs/TOOL_AGENT_USAGE.md:0:0-0:0)** - Comprehensive usage guide
- **[docs/REFACTORING_SUMMARY.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/docs/REFACTORING_SUMMARY.md:0:0-0:0)** - Implementation summary
- **Updated [README.md](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/README.md:0:0-0:0)** - Tool-based agent section with comparison table

### **Key Features:**

✅ **DB Abstraction** - Works with TinyDB, DuckDB, SQLite via `CustomerServiceStore`  
✅ **Plan-Reflect-Execute** - Full workflow from M5 notebook  
✅ **Error Handling** - Human-readable explanations  
✅ **CLI Demo** - `run-customer-service-tool-agent` command  
✅ **Comprehensive Docs** - Usage guides and examples  

### **Usage:**

```python
from multiagent.customer_service import tool_based_agent, DuckDBStore

result = tool_based_agent(
    "I want to buy 2 pairs of Aviator sunglasses",
    store=DuckDBStore(),
    use_reflection=True,
    reseed=True
)
```

```bash
run-customer-service-tool-agent --prompt "I want to buy 2 Aviators" --verbose
```

### **Two Workflow Modes Now Available:**

| Mode             | Flexibility | Safety  | Best For                    |
| ---------------- | ----------- | ------- | --------------------------- |
| **Code-as-Plan** | ✅ High      | ❌ Lower | Exploration, complex logic  |
| **Tool-Based**   | ❌ Limited   | ✅ High  | Production, safety-critical |

The package now provides both approaches, giving you the flexibility to choose based on your needs!