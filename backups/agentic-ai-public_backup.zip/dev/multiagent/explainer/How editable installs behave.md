You usually run `pip install -e .` **once per environment**, not every time you edit code.

### How editable installs behave

After:

```bash
pip install -e .
```

in a given virtualenv:

- The installed package points to your working tree.
- **Editing `.py` files takes effect immediately** (no reinstall needed).
- You can run:

```bash
python -m multiagent.customer_service.cli_single ...
```

from any directory, as long as that env is active.

### When you need to run it again

You only need to re-run `pip install -e .` when:

- **New environment**: you create a new venv/conda env.
- **Project metadata changes** that affect installation:
  - `pyproject.toml` / `setup.cfg` changed in a way that matters:
    - New dependencies / extras you want installed.
    - New console entry points (if you add them).
    - You renamed the project / package structure substantially.

In normal day‑to‑day development (editing modules, adding files under existing packages, adjusting logic), you do **not** rerun it; the editable install tracks those changes automatically.