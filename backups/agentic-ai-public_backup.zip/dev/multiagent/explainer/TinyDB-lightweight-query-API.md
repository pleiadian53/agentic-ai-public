@M5_UGL_1_R.ipynb Cell:27:2-9  Executing this block generates the following code to carry out the plan matching the query"  

```
import re
from datetime import datetime
from tinydb import Query

# Step 1: Initialize
user_text = user_request.strip().lower()
query = Query()

# Step 2: Detect intent (return) and quantity and item name
return_intent = bool(re.search(r'\breturn\b', user_text))
qty_match = re.search(r'(\d+)\s+([a-zA-Z]+)', user_text)
item_name = None
qty = None

if qty_match:
    qty = int(qty_match.group(1))
    item_name = qty_match.group(2)
else:
    # Missing quantity
    STATUS = "invalid_request"
    answer_text = "I can help with that—how many pairs would you like to return?"
    print(f"LOG: ACTION=read DRY_RUN=True STATUS={STATUS}")
    # No mutation
    SHOULD_MUTATE = False
    ACTION = "read"
    # End execution
    raise SystemExit()

# Step 3: Build filter for the requested item name
cond = query.name.test(lambda x, name=item_name: x.lower() == name.lower())

# Step 4: Query inventory for the item
matched = inventory_tbl.search(cond)
if not matched:
    # No matching item
    # Suggest closest by price among available stock
    available = inventory_tbl.search(query.quantity_in_stock.test(lambda s: s > 0))
    if available:
        # cheapest alternative
        alt = min(available, key=lambda r: r['price'])
        STATUS = "no_match"
        answer_text = (
            f"We don’t have {item_name.capitalize()} sunglasses, "
            f"but our {alt['name']} is available for ${alt['price']}."
        )
    else:
        STATUS = "no_match"
        answer_text = "We don’t have that style in stock right now. Please check back later."
    print(f"LOG: ACTION=read DRY_RUN=True STATUS={STATUS}")
    SHOULD_MUTATE = False
    ACTION = "read"
    raise SystemExit()

item = matched[0]

# Step 5: Perform return (mutate)
# Compute refund amount
unit_price = item['price']
line_total = unit_price * qty
refund_amount = -line_total

# Update inventory: increase stock
new_stock = item['quantity_in_stock'] + qty
inventory_tbl.update({'quantity_in_stock': new_stock}, cond)

# Insert transaction for the return
txn_id = next_transaction_id(transactions_tbl)
prev_balance = get_current_balance(transactions_tbl)
new_balance = prev_balance + refund_amount
transactions_tbl.insert({
    'transaction_id': txn_id,
    'customer_name': 'RETURN',
    'transaction_summary': f"Return of {qty} {item['name']} sunglasses",
    'transaction_amount': refund_amount,
    'balance_after_transaction': new_balance,
    'timestamp': datetime.now().isoformat()
})

# Step 6: Prepare output variables
STATUS = "success"
answer_text = f"Sure, I’ve processed your return of {qty} {item['name']} sunglasses and refunded ${line_total}."
print(f"LOG: ACTION=mutate SHOULD_MUTATE=True STATUS={STATUS}")
```

Can you explain "query.quantity_in_stock.test(lambda s: s > 0)"?  is quantity_in_stock an attribute of the dataset? 

---

Yes, `quantity_in_stock` is a field (column) in the inventory dataset. In TinyDB, `Query()` creates a query object that lets you reference fields dynamically:

```python
query = Query()
query.quantity_in_stock  # References the "quantity_in_stock" field
```

The `.test(lambda s: s > 0)` method applies a custom filter function:

- `s` is the **value** of `quantity_in_stock` for each document
- The lambda returns `True` if stock > 0, `False` otherwise
- TinyDB only returns documents where the test passes

So this line:
```python
available = inventory_tbl.search(query.quantity_in_stock.test(lambda s: s > 0))
```

Means: "Find all inventory records where `quantity_in_stock` is greater than 0."

---

### Why use `.test()` instead of direct comparison?

TinyDB's query DSL supports simple comparisons like `query.price > 100`, but for more complex logic (e.g., string matching, custom conditions), you use `.test()` with a lambda.

Examples:
```python
# Simple comparison (built-in)
inventory_tbl.search(query.price > 50)

# Custom logic (requires .test)
inventory_tbl.search(query.name.test(lambda n: "aviator" in n.lower()))

# Null-safe check
inventory_tbl.search(query.description.test(lambda d: d is not None and len(d) > 10))
```

In your code, `.test(lambda s: s > 0)` filters out items with zero or negative stock, ensuring the "closest alternative" suggestion only includes available products.

---

Q: TinyDB provides a lightweight query API?

---

Exactly. TinyDB provides a lightweight query API that covers common filtering needs without SQL:

## Built-in Query Operations

```python
from tinydb import Query

q = Query()

# 1. Equality
inventory_tbl.search(q.name == "Aviator")

# 2. Comparison operators
inventory_tbl.search(q.price > 100)
inventory_tbl.search(q.quantity_in_stock >= 5)

# 3. Logical operators
inventory_tbl.search((q.price < 100) & (q.quantity_in_stock > 0))
inventory_tbl.search((q.name == "Aviator") | (q.name == "Wayfarer"))
inventory_tbl.search(~(q.price > 200))  # NOT

# 4. String matching
inventory_tbl.search(q.name.matches(r'.*aviator.*', flags=re.IGNORECASE))

# 5. Existence checks
inventory_tbl.search(q.description.exists())

# 6. Custom tests (for complex logic)
inventory_tbl.search(q.name.test(lambda n: "round" in n.lower()))
```

## What TinyDB **Doesn't** Support

- ❌ Joins across tables
- ❌ Aggregations (SUM, AVG, GROUP BY)
- ❌ Indexes (everything is scanned)
- ❌ Transactions/ACID guarantees
- ❌ SQL syntax

So yes, TinyDB has "query utilities," but they're intentionally minimal—enough for filtering documents in small datasets, but not a replacement for relational databases when you need complex queries, performance at scale, or data integrity guarantees.

For this lab's sunglasses store demo (dozens of records), TinyDB's query API is perfectly adequate. For production with thousands of SKUs and concurrent transactions, you'd migrate to SQLite/PostgreSQL/DuckDB.	

---

