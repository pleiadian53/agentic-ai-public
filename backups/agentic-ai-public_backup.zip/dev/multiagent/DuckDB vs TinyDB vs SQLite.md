### DuckDB vs TinyDB vs SQLite

- **DuckDB**  
  - OLAP/analytical SQL database.
  - Can be **in‑memory** (default `:memory:`) or **file‑backed** (e.g. `my.db`).
  - Speaks full SQL, integrates tightly with pandas, great for columnar/analytics workloads.

- **TinyDB**  
  - JSON document store, no SQL, simple Python query DSL, best for small demos.

- **SQLite**  
  - File‑based transactional SQL DB (OLTP), ACID, embedded.

So: DuckDB is not “only in‑memory”; it supports both in‑memory and persistent files.