I’ll create a `multiagent/customer_service` package with:

- `data_access.py` (with a `CustomerServiceStore` abstraction and a `TinyDBStore` implementation wired to `inv_utils`).
- `planning.py` and `execution.py` extracted from the notebook.
- `single_agent.py` that exposes a clean `customer_service_agent()` using the store.
- [__init__.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/__init__.py:0:0-0:0) to export the key pieces.

I’ll keep all notebook code unchanged and make the new modules safe to import from scripts or future workflows.

I’ve started the new [multiagent/customer_service](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service:0:0-0:0) package and will now add `data_access.py`, `planning.py`, `execution.py`, and `single_agent.py` wired to TinyDB, keeping the notebook untouched. Then I’ll summarize how to use `customer_service_agent()` from a script or REPL.
Great, I’ve implemented the first pass of the single‑agent package without touching the notebook.

Here’s what you now have and how to use it.

---

## 1. New package layout

```text
multiagent/
  customer_service/
    __init__.py
    data_access.py      # data layer abstraction + TinyDB backend
    planning.py         # prompt + generate_llm_code(...)
    execution.py        # extract_execute_block + execute_generated_code(...)
    single_agent.py     # customer_service_agent(...)
```

Exports (via [__init__.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/eval/__init__.py:0:0-0:0)):

- [CustomerServiceStore](cci:2://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:17:0-58:11)
- [TinyDBStore](cci:2://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:61:0-118:68)
- [generate_llm_code](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/planning.py:94:0-130:18)
- [execute_generated_code](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/execution.py:32:0-88:5)
- [customer_service_agent](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/single_agent.py:24:0-101:5)

---

## 2. Data access abstraction ([data_access.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:0:0-0:0))

### Interface

```python
class CustomerServiceStore(ABC):
    def seed_demo_data(self) -> None: ...
    def get_inventory_rows(self) -> list[dict[str, Any]]: ...
    def get_transaction_rows(self) -> list[dict[str, Any]]: ...
    def get_current_balance(self) -> float: ...
    def next_transaction_id(self, prefix: str = "TXN") -> str: ...
    def update_inventory_quantity(self, item_id: str, new_qty: int) -> None: ...
    def insert_transaction(self, row: dict[str, Any]) -> None: ...
    def get_raw_handles(self) -> tuple[Any, Any, Any]: ...
```

This is where generalizing to SQLite/MySQL will happen later: just implement this interface for other backends.

### TinyDB implementation

```python
store = TinyDBStore(path="store_db.json")
store.seed_demo_data()          # recreate demo data
rows = store.get_inventory_rows()
balance = store.get_current_balance()
```

[get_raw_handles()](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:114:4-118:68) returns `(db, inventory_tbl, transactions_tbl)` so the current executor can still work with TinyDB tables.

---

## 3. Planning ([planning.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/planning.py:0:0-0:0))

- `PROMPT` is essentially the same as in [M5_UGL_1_R.ipynb](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/M5_lab1/M5_UGL_1_R.ipynb:0:0-0:0).
- [generate_llm_code(...)](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/planning.py:94:0-130:18) encapsulates the LLM call:

```python
from multiagent.customer_service.planning import generate_llm_code

content = generate_llm_code(
    "Return 2 Aviator sunglasses I bought last week.",
    inventory_tbl=inventory_tbl,
    transactions_tbl=transactions_tbl,
    model="o4-mini",
    temperature=0.8,
    client=client,  # optional OpenAI()
)
```

No notebook rendering inside; it just returns the LLM’s content string.

---

## 4. Execution ([execution.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/execution.py:0:0-0:0))

- [extract_execute_block(text)](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/execution.py:20:0-29:52) pulls Python from `<execute_python> ... </execute_python>`.
- [execute_generated_code(...)](cci:1://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/execution.py:32:0-88:5) runs it in a constrained namespace:

```python
from multiagent.customer_service.execution import execute_generated_code

result = execute_generated_code(
    full_content,
    db=db,
    inventory_tbl=inventory_tbl,
    transactions_tbl=transactions_tbl,
    user_request=question,
)

# result keys: code, stdout, error, answer, inventory_tbl, transactions_tbl
```

Namespace is still TinyDB‑specific, but it’s now isolated to this module.

---

## 5. Single‑agent entrypoint ([single_agent.py](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/single_agent.py:0:0-0:0))

This is your main reusable function:

```python
from multiagent.customer_service import TinyDBStore, customer_service_agent
from openai import OpenAI

store = TinyDBStore()           # TinyDB backend
client = OpenAI()

result = customer_service_agent(
    "I want to buy 3 pairs of classic sunglasses and 1 pair of aviator sunglasses.",
    store=store,
    model="o4-mini",
    temperature=1.0,
    reseed=True,   # recreate demo data for a clean run
    client=client,
)
```

`result` structure:

```python
{
  "question": "...",
  "full_content": "<execute_python>...</execute_python>",
  "exec": {
    "code": "...",                # extracted python
    "stdout": "...",              # logs printed by plan
    "error": None or "traceback",
    "answer": "short user-facing answer",
    "inventory_after": [...],     # list of dicts
    "transactions_after": [...],
  },
}
```

You can pretty‑print:

```python
print("USER:", result["question"])
print("ANSWER:", result["exec"]["answer"])
print("LOGS:\n", result["exec"]["stdout"])
if result["exec"]["error"]:
    print("ERROR:\n", result["exec"]["error"])
```

---

## 6. Generalizing beyond TinyDB

The design is already set up for SQLite/MySQL:

- Keep the **agent and planning/execution code unchanged**.
- Add new backends that implement [CustomerServiceStore](cci:2://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:17:0-58:11):

```python
class SQLiteStore(CustomerServiceStore):
    # use sqlite3 or SQLAlchemy under the hood
    ...

class MySQLStore(CustomerServiceStore):
    # use a MySQL driver/SQLAlchemy
    ...
```

Then you can switch simply by:

```python
from multiagent.customer_service import customer_service_agent
from multiagent.customer_service.data_access import SQLiteStore

store = SQLiteStore("sqlite:///customer_service.db")
result = customer_service_agent("Return 2 Aviator sunglasses", store=store)
```

We don’t need to change the notebook to do this; the new package is self‑contained.

---

## 7. Next steps (if you’d like)

- Add a small `cli_single.py` driver in [multiagent/customer_service/](cci:7://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service:0:0-0:0) that you can run via `python -m multiagent.customer_service.cli_single`.
- Start sketching `multiagent/customer_service/multi_agent/` that mirrors the M5 multi‑agent notebook (planner, reflector, executor, explainer) using the same [CustomerServiceStore](cci:2://file:///Users/pleiadian53/work/agentic-ai-public/multiagent/customer_service/data_access.py:17:0-58:11) abstraction.

If you want, I can add the CLI driver next and/or stub out a `SQLiteStore` interface so you can see what the SQL version would look like.