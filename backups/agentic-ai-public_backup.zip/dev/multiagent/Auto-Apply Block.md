> `multiagent/M5_lab1/M5_UGL_1.ipynb`
>
> * execute_plan_tools_only()



Yes, exactly! **Line 363 is the heart of tool execution** - that's where the actual tool function gets called.

## Explanation of the Auto-Apply Block (Lines 366-377)

This block implements **automatic state propagation** for write tools:

```python
# auto-apply: if the tool returned updated DataFrame(s), refresh the context and DuckDB
mutated = False
if isinstance(res, dict):
    if "inventory_df" in res and isinstance(res["inventory_df"], pd.DataFrame):
        ctx["__frames__"]["inventory_df"] = res["inventory_df"]
        ctx["__con__"].unregister("inventory_df")
        ctx["__con__"].register("inventory_df", res["inventory_df"])
        mutated = True
    if "transaction_df" in res and isinstance(res["transaction_df"], pd.DataFrame):
        ctx["__frames__"]["transaction_df"] = res["transaction_df"]
        ctx["__con__"].unregister("transaction_df")
        ctx["__con__"].register("transaction_df", res["transaction_df"])
        mutated = True
```

### What's Happening:

1. **Check if tool returned updated DataFrames:**
   - Write tools like `update_inventory` and `append_transaction` return new DataFrames in their result dict
   - Example: `{"inventory_df": updated_df, "updated": {...}}`

2. **Update the context:**
   - Replace `ctx["__frames__"]["inventory_df"]` with the new version
   - This ensures subsequent tools see the updated data

3. **Sync DuckDB connection:**
   - `unregister("inventory_df")` - Remove old DataFrame from DuckDB
   - `register("inventory_df", new_df)` - Register updated DataFrame
   - This keeps DuckDB queries in sync with the latest state

4. **Mark as mutated:**
   - Sets `mutated = True` and adds `"__applied__": True` to result
   - Signals that state was changed

### Why This Matters:

**Without this auto-apply:**
```python
# Step 1: Update inventory (returns new DataFrame)
result1 = update_inventory(...)  # Returns {"inventory_df": df_with_qty_10, ...}

# Step 2: Another update - would use OLD DataFrame!
result2 = update_inventory(...)  # Still sees original DataFrame, not df_with_qty_10
```

**With auto-apply:**
```python
# Step 1: Update inventory
result1 = update_inventory(...)
# → Context automatically updated with new DataFrame

# Step 2: Another update - sees UPDATED DataFrame
result2 = update_inventory(...)  # Sees df_with_qty_10 from step 1
```

This is crucial for **sequential tool execution** where later tools depend on mutations from earlier tools.

---

## Improved Comments

Let me add comprehensive comments to the function:

Perfect! Now the function has comprehensive comments. Let me create a visual summary:

## Summary: Tool Execution Flow

```
┌─────────────────────────────────────────────────────────────┐
│  run_tools_for_step(step, ctx)                              │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
        ┌──────────────────────────────────────┐
        │  For each tool in step["tools"]:     │
        └──────────────────────────────────────┘
                           │
        ┌──────────────────┴──────────────────┐
        │                                      │
        ▼                                      ▼
┌──────────────────┐              ┌──────────────────────┐
│ 1. Extract spec  │              │ 2. Lookup function   │
│    - name        │              │    fn = REGISTRY[..] │
│    - result_key  │              └──────────────────────┘
│    - args        │                         │
└──────────────────┘                         ▼
        │                          ┌──────────────────────┐
        └─────────────────────────>│ 3. Prepare args      │
                                   │    - resolve_args    │
                                   │    - canonicalize    │
                                   │    - validate        │
                                   │    - inject handles  │
                                   └──────────────────────┘
                                              │
                                              ▼
                                   ┌──────────────────────┐
                                   │ 4. EXECUTE TOOL ⭐   │
                                   │    res = fn(**args)  │
                                   └──────────────────────┘
                                              │
                                              ▼
                                   ┌──────────────────────┐
                                   │ 5. Auto-apply state  │
                                   │    If res contains:  │
                                   │    - inventory_df    │
                                   │    - transaction_df  │
                                   │    → Update context  │
                                   │    → Sync DuckDB     │
                                   └──────────────────────┘
                                              │
                                              ▼
                                   ┌──────────────────────┐
                                   │ 6. Store result      │
                                   │    ctx[rkey] = res   │
                                   └──────────────────────┘
```

## Key Insights

### Line 401: `res = fn(**args)` ⭐
**This is the heart of tool execution** - where the actual work happens:
- `fn` is the tool function from `TOOL_REGISTRY`
- `args` are fully prepared (resolved, canonicalized, validated, injected)
- `res` is the tool's return value (usually a dict)

### Lines 408-422: Auto-Apply Block 🔄
**Critical for sequential tool execution:**

```python
# Without auto-apply:
Step 1: update_inventory(qty=10) → returns new DataFrame
Step 2: update_inventory(qty=5)  → uses OLD DataFrame ❌

# With auto-apply:
Step 1: update_inventory(qty=10) → returns new DataFrame
        → Context updated automatically ✓
Step 2: update_inventory(qty=5)  → uses UPDATED DataFrame ✓
```

**Three-way sync:**
1. **Tool returns** updated DataFrame
2. **Context updated** → `ctx["__frames__"]["inventory_df"] = new_df`
3. **DuckDB synced** → `unregister()` + `register(new_df)`

This ensures:
- Subsequent tools see mutations
- DuckDB queries reflect changes
- State consistency across the execution

### Why This Design?

**Immutable DataFrames + Explicit Returns:**
- Pandas DataFrames are conceptually immutable in this pattern
- Tools return new DataFrames rather than mutating in-place
- Executor automatically propagates the new state

**Benefits:**
- ✅ Clear data flow (tool → new state → context)
- ✅ Testable (can inspect intermediate states)
- ✅ Safe (no hidden mutations)

**Trade-off:**
- ❌ More memory (copying DataFrames)
- ❌ More complex executor logic

This is why **code-as-plan** can be simpler - it directly mutates TinyDB tables without needing this propagation machinery!